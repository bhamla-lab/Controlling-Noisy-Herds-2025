%% This code simulates the Gillespie's algorithm for the evolution of a group of 5 agents starting from a random initial condition. We calculate the time it first reaches a shedding state. 
clear all
clc
close all

Size = 1000; % Matrix size


OP75 = zeros(Size,Size); %Split the agent in 3:2 ratio in right and left. 

% 
% %% Colormap
% 
% % Define the RGB values for navy blue and neon green
% navy_neongreen_data = [0,0,128; 57,255,20]/255;
% 
% % Generate a linearly spaced vector from 1 to the size of navy_neongreen_data
% indices = linspace(1, size(navy_neongreen_data, 1), 256);
% 
% % Use interpolation to generate the colormap
% navy_neongreen = interp1(1:size(navy_neongreen_data, 1), navy_neongreen_data, indices);

NumSheep = 5;

for JJ = 1:Size
   JJ
    for KK = 1:Size

           for Repeat = 1:200
               Time = [];
       
        TotTime = 500;

      %% Random initial conditions
         Sequence = randperm(4);
        Values = randi(5,1,4);

        Sum = cumsum(Values);
        if Sum<=NumSheep
            Values(4) = Values(4) + 5-Sum(4);
        else
        Cutoff = find(Sum>NumSheep);
        Cutoff = Cutoff(1);
        Values(Cutoff) = Values(Cutoff) - (Sum(Cutoff)-5);
        Values(Cutoff+1:end) = 0;
        end

        x1 = Values(Sequence == 1); %Towards Hander
        x_1 = Values(Sequence == 2); %Towards dog
        x2 = Values(Sequence == 3); %East
        x_2 = Values(Sequence == 4); %West
        x3 = 0;
        x_3 = 0;
        x4 = 0;
        x_4 = 0;

        X = [x1, x_1, x2, x_2, x3, x_3, x4, x_4]; % 3 and -3 are direction in vertical direction and 4 and -4 are horizontal


        %X = [x1, x_1, x2, x_2, x3, x_3, x4, x_4]; % 3 and -3 are direction in vertical direction and 4 and -4 are horizontal

        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.001;%Random switching

        alpha1_scare = 0.05+JJ*.001; % Negative_reinforcement from the dog
        alpha_1_scare = 0.05+JJ*.001 ; %Negative_reinforcement from the handler
        alpha12_scare = KK*alpha1_scare/Size; % Negative_reinforcement from the dog [alpha12_scare and alpha1_2_scare are same

        alpha_12_scare = KK*alpha_1_scare/Size; % Negative_reinforcement from the dog (same as alpha_1_2_scare)

        alpha1_lure = 0; % Unnecessary parameter
        alpha_1_lure = 0; % Unnecessary parameter for the shed
        phi = 10000 ; %Leader to follower transformation

        for i = 1:TotTime
            


            %% propensities

            P_noise = repelem(X(1:4),1,3)*eps;

            P_interaction_matrix = gamma * X' * X;

            % IN the same direction, the pointer has to copy pointers other
            % than itself. So it shouod be x(x-1) on the diagonals

            diagInd = find(eye(size(P_interaction_matrix)));

%             Replace diagonal elements with NaN
     
            Self_Mult = X.*(X-1);
            Self_Mult(Self_Mult<=0) = 0;
        
            P_interaction_matrix(diagInd) = Self_Mult'*gamma;

            % shift ith row circularly i times so that the sequence becomes
            % 1-2-3-4-5-1 and the To formula works

            % Find the linear indices of the diagonal elements
            %diagInd = find(eye(size(P_interaction_matrix)));

            % Replace diagonal elements with NaN
            % P_interaction_matrix(diagInd) = NaN;

            P_interaction_matrix(5:8,:) = NaN; %Leaders don't follow anyon

            % Flatten the matrix
            P_interaction_matrix_Transpose = P_interaction_matrix';
            P_interaction_matrix_flat =  P_interaction_matrix_Transpose(:);

            % Remove NaN values
            P_interaction = P_interaction_matrix_flat(~isnan(P_interaction_matrix_flat))';

            P_activation = [repelem(X(1:2),1,3), repelem(X(3:4),1,2), X(1:2)].*[repelem([alpha1_scare, alpha_1_scare],1,3), repmat([alpha_12_scare, alpha12_scare],1,2) alpha1_lure, alpha_1_lure];
            P_deactivation = X(5:8).*phi;

            TotProp = sum([P_noise P_interaction P_activation P_deactivation]);

            p_noise = P_noise/TotProp;
            p_interaction = P_interaction/TotProp;
            p_activation = P_activation/TotProp;
            p_deactivation = P_deactivation/TotProp;

            PT = cumsum([p_noise, p_interaction, p_activation, p_deactivation]);

            TotNoise = length(p_noise);
            TotInteraction = length(p_interaction);
            TotActivation = length(p_activation);
            TotDeactivation = length(P_deactivation);

            TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation, TotDeactivation]);

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                %disp('Noise')

                From = floor(Find_Reaction/3)+1;
                Mod = mod(Find_Reaction,3);
                if Mod == 0
                    From = From -1;
                    Mod = 3;
                end
                To = mod(From + Mod,4);

                if To == 0
                    To = 4;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                %disp('Interaction')

                Reaction = Find_Reaction - TotNoise;

                %% Use this block when self interaction is not valid. In that case, circular shift is necessary in the p_interaction step.

                %             From = floor(Reaction/7)+1;
                %
                %             Mod = mod(Reaction,7);
                %             if Mod == 0
                %                 From = From -1;
                %                 Mod = 7;
                %             end
                %
                %             To = mod(From + Mod,8);
                %%
                From = floor(Reaction/8)+1;

                Mod = mod(Reaction,8);
                if Mod == 0
                    From = From -1;
                end

                To = Mod;

                if To == 0
                    To = 4;
                end

                if To == 7
                    To = 3;
                end

                if To == 6
                    To = 2;
                end
                if To == 5
                    To = 1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation)

                %% Activation

                % Reactions = [16 17 18 27 28 25 35 36 45 46 15 26]

                %disp('Activation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                if Reaction <=6
                    From = floor(Reaction/3)+1;
                    Mod = mod(Reaction,3);
                    if Mod == 0
                        From = From -1;
                        Mod = 3;
                    end
                    To = mod(From + Mod,4);

                    if To == 0
                        To = 4;
                    end

                    To = To + 4;
                else

                    FromOptions = ceil(Reaction/2);


                    switch FromOptions
                        case 4
                            From = 3;
                        case 5
                            From = 4;
                        case 6
                            if Reaction == 11
                                From = 1;
                            else
                                From = 2;
                            end
                    end

                    if mod(Reaction,2) == 0
                        To = 6;
                    else
                        To = 5;
                    end
                end



            else
                %% Deactivation

                %disp('Deactivation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation);

                To = Reaction;
                From = Reaction + 4;

            end

            X(From) = X(From) -1;
            X(To) = X(To) + 1;

            Time(i) = (1/TotProp).*log(1/r1);

       

            Vertical_OP = X(1) - X(2);
            Horizontal_OP = X(3)-X(4);

            XT(i,:) = X;

            XVec(:,1) = X(1) * [1 0]';
            XVec(:,5) = X(5) * [1 0]';
            XVec(:,2) = X(2) * [-1 0]';
            XVec(:,6) = X(6) * [-1 0]';
            XVec(:,3) = X(3) * [0 1]';
            XVec(:,7) = X(7) * [0 1]';
            XVec(:,4) = X(4) * [0 -1]';
            XVec(:,8) = X(8) * [0 -1]';

            %% OP in horizontal direction calculation

            Xtop = X(1) + X(5);
            Xbottom = X(2) + X(6);
            Xright = X(3) + X(7);
            Xleft = X(4) + X(8);

            Xhor = Xright + Xleft;
            Xver = Xtop + Xbottom;

            if Xhor == 0
                Xhor = 1;
            end

            XRelHor = (Xhor - Xver)/sum(X);

            if XRelHor == 1

                OPDirect(i) = (abs(Xright-Xleft)/Xhor);
            else
                OPDirect(i) = 0;
            end

            if OPDirect(i) == 0.2
                break;
            end

     

        end

        OP75_FPT(Repeat) = sum(Time(1:end-1));
           end

           OP75 (JJ,KK) = mean(OP75_FPT);

        
    end
end

% File = 'The_shed_OP100_Better_OP_Calc_phi_0.01';
% save(File,"OP100");
% 
File = 'Smooth_1000_FPT_The_shed_OP75_Phi_10000';
save(File,"OP75");

imagesc(OP75);
        
        set(gca, 'YDir','normal')
colorbar;

% Add axes labels
ylabel('Pressure','FontSize',14);
xlabel('Lighness of the sheep','FontSize',14);
xticks(100:100:1000)
xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})

yticks(50:50:500)
yticklabels({'1', '2', '3', '4','5','6','7',8','9','10'})
% Save the image as SVG
saveas(gcf, ' Smooth_1000_Range_FPT_Shed_Phase_diagram_OP75_Better_OP_Calc_Phi_10000.svg', 'svg');

% Save the image as FIG
savefig(' Smooth_1000_Range_FPT_Shed_phase_diagram_OP75_Better_OP_Calc_Phi_10000.fig')
% 

% % Save Figure
% 
% 
% for Fig = 1:3
% 
% Yvalues  = 0.005:0.005:0.5;
% Xvalues = 0.01:0.01:1;
% figure;
% switch Fig 
%     case 1
% imagesc(OP50Time);
% colormap(navy_neongreen)
% set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% 
% 
% 
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP50_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP50_Better_OP_Calc_Phi_0.05.fig')
% 
%     case 2
%         imagesc(OP75Time);
%         colormap(navy_neongreen)
%         set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % % Get the maximum and minimum values in the colorbar
% % caxisValues = caxis;
% % cmin = caxisValues(1);
% % cmax = caxisValues(2);
% % %c.Label.String = 'Colorbar Label';
% % c.Ticks = [cmin cmax];
% % c.TickLabels = {'DA', 'TA'};
% 
% % % Set tick values for x and y axes
% %  xticks('auto');
% % yticks([10 100 1000 10000]);
% %
% % % Set custom tick labels for x-axis
% % yticklabels({'10^1','10^2', '10^3','10^4'});
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP75_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP75_Better_OP_Calc_Phi_0.05.fig')
%     case 3
%          imagesc(OP100);
%          colormap(navy_neongreen)
%          set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % % Get the maximum and minimum values in the colorbar
% % caxisValues = caxis;
% % cmin = caxisValues(1);
% % cmax = caxisValues(2);
% % %c.Label.String = 'Colorbar Label';
% % c.Ticks = [cmin cmax];
% % c.TickLabels = {'DA', 'TA'};
% 
% % % Set tick values for x and y axes
% %  xticks('auto');
% % yticks([10 100 1000 10000]);
% %
% % % Set custom tick labels for x-axis
% % yticklabels({'10^1','10^2', '10^3','10^4'});
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP100_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP100_Better_OP_Calc_Phi_0.05.fig')
% end
% end


