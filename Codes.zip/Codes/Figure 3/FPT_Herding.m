%% 7/24 This code simulates (SSA) the switching dynamics of the herd of 1d agents in presence of active agents.
%% Starting from any initial condition, we calculate the time taken for a group of 5 agents to enter a herding state.
%% This code implements Gillespie's algorithm to solve the 1D herding problem

%% We model it as a general model. When influenced by the controller, the agent gets "activated" and changes orientation with rate \alpha. It then gets "deactivated" with rate phi. 
% We choose rate phi \to infinity, to eliminate the idea of activation and deactivation in sheep system.  
clear all
clc
close all

Size = 1000; % Total matrix size

OPHerd = zeros(Size,Size); % Matrix for herding 
NumSheep = 5;

%% Colormap

% Define the RGB values for navy blue and neon green
navy_neongreen_data = [0,0,128; 57,255,20]/255;

% Generate a linearly spaced vector from 1 to the size of navy_neongreen_data
indices = linspace(1, size(navy_neongreen_data, 1), 256);

% Use interpolation to generate the colormap
navy_neongreen = interp1(1:size(navy_neongreen_data, 1), navy_neongreen_data, indices);


for JJ = 1:Size

    for KK = 1:Size

           for Repeat = 1:200
               Time = [];
       
        TotTime = 500; % Total time of simulation

        XT = zeros(TotTime,8);

        %% Random initial conditions
         Sequence = randperm(4);
         Values = randi(5,1,4);
         Sum = cumsum(Values);

        if Sum<=NumSheep
            Values(4) = Values(4) + 5-Sum(4);
        else
        Cutoff = find(Sum>NumSheep);
        Cutoff = Cutoff(1);
        Values(Cutoff) = Values(Cutoff) - (Sum(Cutoff)-5);
        Values(Cutoff+1:end) = 0;
        end

        x1 = Values(Sequence == 1); % Number of agents in North direction
        x_1 = Values(Sequence == 2); % Number of agents in South direction
        x2 = Values(Sequence == 3); % Number of agents in East direction
        x_2 = Values(Sequence == 4); % Number of agents in West direction
        x3 = 0;  
        x_3 = 0;
        x4 = 0;
        x_4 = 0;

        X = [x1, x_1, x2, x_2, x3, x_3, x4, x_4]; % 3 and -3 are direction in vertical direction and 4 and -4 are horizontal

        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.001;%Random switching

        alpha1_scare = 0; % Negative_reinforcement from the handler when the sheep is looking at the handler
        alpha_1_scare = 0.05 + JJ*.001; %Negative_reinforcement from the dog when the sheep is looking at the dog
        alpha12_scare = KK*alpha1_scare/Size; % Negative_reinforcement from the handler if the sheep is looking perpendicular to the handler [alpha12_scare and alpha1_2_scare are same

        alpha_12_scare = KK*alpha_1_scare/Size; % Negative_reinforcement from the dog if the sheep is looking perpendicular to the dog (same as alpha_1_2_scare)

        
        alpha1_lure = 0; % Unnecessary parameters for the herding problem. 
        alpha_1_lure = 0; % Unnecesary parameters for the herding problem

        phi = 10000  ; %Leader to follower transformation. It is related to the activation-deactivation problem described in the beginning of the code. 

        for i = 1:TotTime
            

            %% propensities
            P_noise = repelem(X(1:4),1,3)*eps; % Noise

            P_interaction_matrix = gamma * X' * X; %Interaction

            % IN the same direction, the pointer has to copy pointers other
            % than itself. So it shouod be x(x-1) on the diagonals

            diagInd = find(eye(size(P_interaction_matrix)));

%             Replace diagonal elements with NaN
     
            Self_Mult = X.*(X-1);
            Self_Mult(Self_Mult<=0) = 0;
        
            P_interaction_matrix(diagInd) = Self_Mult'*gamma; %Interaction Matrix

            P_interaction_matrix(5:8,:) = NaN; %Leaders don't follow anyone

            % Flatten the matrix
            P_interaction_matrix_Transpose = P_interaction_matrix';
            P_interaction_matrix_flat =  P_interaction_matrix_Transpose(:);

            % Remove NaN values
            P_interaction = P_interaction_matrix_flat(~isnan(P_interaction_matrix_flat))';

            P_activation = [repelem(X(1:2),1,3), repelem(X(3:4),1,2), X(1:2)].*[repelem([alpha1_scare, alpha_1_scare],1,3), repmat([alpha_12_scare, alpha12_scare],1,2) alpha1_lure, alpha_1_lure];
            P_deactivation = X(5:8).*phi;

            TotProp = sum([P_noise P_interaction P_activation P_deactivation]);

            p_noise = P_noise/TotProp;
            p_interaction = P_interaction/TotProp;
            p_activation = P_activation/TotProp;
            p_deactivation = P_deactivation/TotProp;

            PT = cumsum([p_noise, p_interaction, p_activation, p_deactivation]);

            TotNoise = length(p_noise);
            TotInteraction = length(p_interaction);
            TotActivation = length(p_activation);
            TotDeactivation = length(P_deactivation);

            TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation, TotDeactivation]);

            r1 = rand; %Random number deciding when it will happen
            r2 = rand;  %Random number deciding which reaction will happen
           

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                %disp('Noise')

                From = floor(Find_Reaction/3)+1;
                Mod = mod(Find_Reaction,3);
                if Mod == 0
                    From = From -1;
                    Mod = 3;
                end
                To = mod(From + Mod,4);

                if To == 0
                    To = 4;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                %disp('Interaction')

                Reaction = Find_Reaction - TotNoise;

                From = floor(Reaction/8)+1;

                Mod = mod(Reaction,8);
                if Mod == 0
                    From = From -1;
                end

                To = Mod;

                if To == 0
                    To = 4;
                end

                if To == 7
                    To = 3;
                end

                if To == 6
                    To = 2;
                end
                if To == 5
                    To = 1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation)

                %% Activation

                %disp('Activation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                if Reaction <=6
                    From = floor(Reaction/3)+1;
                    Mod = mod(Reaction,3);
                    if Mod == 0
                        From = From -1;
                        Mod = 3;
                    end
                    To = mod(From + Mod,4);

                    if To == 0
                        To = 4;
                    end

                    To = To + 4;
                else

                    FromOptions = ceil(Reaction/2);


                    switch FromOptions
                        case 4
                            From = 3;
                        case 5
                            From = 4;
                        case 6
                            if Reaction == 11
                                From = 1;
                            else
                                From = 2;
                            end
                    end

                    if mod(Reaction,2) == 0
                        To = 6;
                    else
                        To = 5;
                    end
                end



            else
                %% Deactivation

                %disp('Deactivation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation);

                To = Reaction;
                From = Reaction + 4;

            end

            X(From) = X(From) -1;
            X(To) = X(To) + 1;

            Time(i) = (1/TotProp).*log(1/r1);

%             Vertical_OP = X(1) - X(2); %Vertical Order parameter
%             Horizontal_OP = X(3)-X(4); %Horizontal Order parameter
% 
%             XT(i,:) = X;
% 
%             XVec(:,1) = X(1) * [1 0]';
%             XVec(:,5) = X(5) * [1 0]';
%             XVec(:,2) = X(2) * [-1 0]';
%             XVec(:,6) = X(6) * [-1 0]';
%             XVec(:,3) = X(3) * [0 1]';
%             XVec(:,7) = X(7) * [0 1]';
%             XVec(:,4) = X(4) * [0 -1]';
%             XVec(:,8) = X(8) * [0 -1]';

            %% OP in horizontal direction calculation

            Xtop = X(1) + X(5); % Total number of agents towards the handler (N direction)
            Xbottom = X(2) + X(6); % Total number of agents towards the dog (S direction)
            Xright = X(3) + X(7); % Total number of agents towards the right 
            Xleft = X(4) + X(8); % Total number of agents towards the left

           OPDirect_Herd(i) = Xtop/sum(X);

            if OPDirect_Herd(i) == 1
                break;
            end

        end

        OPHerd_FPT(Repeat) = sum(Time(1:end-1));
           end

           OPHerd (JJ,KK) = mean(OPHerd_FPT);
       
    end
end

% File = 'The_shed_OP100_Better_OP_Calc_phi_0.01';
% save(File,"OP100");
% 
File = 'Smooth_FPT_OPHerd_Phi__10000';
save(File,"OPHerd");

imagesc(OPHerd);
        colormap(navy_neongreen)
        set(gca, 'YDir','normal')
colorbar;

% Add axes labels
% Add axes labels
ylabel('Pressure','FontSize',14);
xlabel('Lighness of the sheep','FontSize',14);
xticks(10:10:100)
xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})

yticks(10:10:100)
yticklabels({'1', '2', '3', '4','5','6','7','8','9','10'})

% Save the image as SVG
saveas(gcf, 'Smooth_FPT_OPHerd_Phi__10000', 'svg');

% Save the image as FIG
savefig('Smooth_FPT_OPHerd_Phi__10000.fig')
% 

% % Save Figure
% 
% 
% for Fig = 1:3
% 
% Yvalues  = 0.005:0.005:0.5;
% Xvalues = 0.01:0.01:1;
% figure;
% switch Fig 
%     case 1
% imagesc(OP50Time);
% colormap(navy_neongreen)
% set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% 
% 
% 
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP50_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP50_Better_OP_Calc_Phi_0.05.fig')
% 
%     case 2
%         imagesc(OP75Time);
%         colormap(navy_neongreen)
%         set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % % Get the maximum and minimum values in the colorbar
% % caxisValues = caxis;
% % cmin = caxisValues(1);
% % cmax = caxisValues(2);
% % %c.Label.String = 'Colorbar Label';
% % c.Ticks = [cmin cmax];
% % c.TickLabels = {'DA', 'TA'};
% 
% % % Set tick values for x and y axes
% %  xticks('auto');
% % yticks([10 100 1000 10000]);
% %
% % % Set custom tick labels for x-axis
% % yticklabels({'10^1','10^2', '10^3','10^4'});
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP75_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP75_Better_OP_Calc_Phi_0.05.fig')
%     case 3
%          imagesc(OP100);
%          colormap(navy_neongreen)
%          set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Lighness of the sheep','FontSize',14);
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Set tick labels and tick values on the colorbar
% c = colorbar;
% 
% % % Get the maximum and minimum values in the colorbar
% % caxisValues = caxis;
% % cmin = caxisValues(1);
% % cmax = caxisValues(2);
% % %c.Label.String = 'Colorbar Label';
% % c.Ticks = [cmin cmax];
% % c.TickLabels = {'DA', 'TA'};
% 
% % % Set tick values for x and y axes
% %  xticks('auto');
% % yticks([10 100 1000 10000]);
% %
% % % Set custom tick labels for x-axis
% % yticklabels({'10^1','10^2', '10^3','10^4'});
% 
% % Set font size for all elements
% set(gca, 'FontSize', 14);
% 
% % Save the image as SVG
% saveas(gcf, 'Shed_Phase_diagram_OP100_Better_OP_Calc_Phi_0.05.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Shed_phase_diagram_OP100_Better_OP_Calc_Phi_0.05.fig')
% end
% end


