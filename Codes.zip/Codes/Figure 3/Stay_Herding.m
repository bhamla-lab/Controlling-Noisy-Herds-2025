%% 7/24 This code simulates (SSA) Shed problemthe switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem

%% 9/17: This code has been updated to also record herding OP = 1. THe agitation is minimized. So an active agent quickly becomes inactive. so phi  is really high. Later, we will study the effect of agitation
clear all
clc
close all

Size = 1000;

OP100 = zeros(Size,Size);
OP75 = zeros(Size,Size);
OP50 = zeros(Size,Size);

%% Colormap

% Define the RGB values for navy blue, neon green, and yellow
navy_blue = [0, 0, 128] / 255;  % RGB for navy blue
neon_green = [57, 255, 20] / 255;  % RGB for neon green
yellow = [255, 255, 0] / 255;  % RGB for yellow

% Create a colormap with a smooth transition from blue to green to yellow
navy_neongreen = [linspace(navy_blue(1), neon_green(1), 128), ...
             linspace(neon_green(1), yellow(1), 128); ...
             linspace(navy_blue(2), neon_green(2), 128), ...
             linspace(neon_green(2), yellow(2), 128); ...
             linspace(navy_blue(3), neon_green(3), 128), ...
             linspace(neon_green(3), yellow(3), 128)]';

% % Define the RGB values for navy blue and neon green
% navy_neongreen_data = [0,0,128; 57,255,20]/255;
% 
% % Generate a linearly spaced vector from 1 to the size of navy_neongreen_data
% indices = linspace(1, size(navy_neongreen_data, 1), 256);
% 
% % Use interpolation to generate the colormap
% navy_neongreen = interp1(1:size(navy_neongreen_data, 1), navy_neongreen_data, indices);


for JJ = 1:Size
   JJ
    for KK = 1:Size

        OPDirect_Shed = [];
       
        TotTime = 10000;

        XT = zeros(TotTime,8);
        % concentrations:
        x1 = 2;
        x_1 = 1;
        x2 = 1;
        x_2 = 1;
        x3 = 0;
        x_3 = 0;
        x4 = 0;
        x_4 = 0;

        X = [x1, x_1, x2, x_2, x3, x_3, x4, x_4]; % 3 and -3 are direction in vertical direction and 4 and -4 are horizontal

        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.001;%Random switching

       %% 9/18/2023: We observed that 0 represents direction away from the alpha direction. So alpha_1_scare is the direction of the dog as OP becomes 1 for that.

        alpha1_scare = 0; % Negative_reinforcement from the dog
        alpha_1_scare = 0.05 + JJ*.001; %Negative_reinforcement from the handler
        alpha12_scare = KK*alpha1_scare/Size; % Negative_reinforcement from the dog [alpha12_scare and alpha1_2_scare are same

        alpha_12_scare = KK*alpha_1_scare/Size; % Negative_reinforcement from the dog (same as alpha_1_2_scare)

        

        alpha1_lure = 0;
        alpha_1_lure = 0;
        phi = 10000  ; %Leader to follower transformation

        for i = 1:TotTime

            %% propensities

            P_noise = repelem(X(1:4),1,3)*eps;

            P_interaction_matrix = gamma * X' * X;

            % IN the same direction, the pointer has to copy pointers other
            % than itself. So it shouod be x(x-1) on the diagonals

            diagInd = find(eye(size(P_interaction_matrix)));

%             Replace diagonal elements with NaN
     
            Self_Mult = X.*(X-1);
            Self_Mult(Self_Mult<=0) = 0;
        
            P_interaction_matrix(diagInd) = Self_Mult'*gamma;

            % shift ith row circularly i times so that the sequence becomes
            % 1-2-3-4-5-1 and the To formula works

            % Find the linear indices of the diagonal elements
            %diagInd = find(eye(size(P_interaction_matrix)));

            % Replace diagonal elements with NaN
            % P_interaction_matrix(diagInd) = NaN;

            P_interaction_matrix(5:8,:) = NaN; %Leaders don't follow anyone


            %Leaders don't follow anyone

            % Flatten the matrix
            P_interaction_matrix_Transpose = P_interaction_matrix';
            P_interaction_matrix_flat =  P_interaction_matrix_Transpose(:);

            % Remove NaN values
            P_interaction = P_interaction_matrix_flat(~isnan(P_interaction_matrix_flat))';

            P_activation = [repelem(X(1:2),1,3), repelem(X(3:4),1,2), X(1:2)].*[repelem([alpha1_scare, alpha_1_scare],1,3), repmat([alpha_12_scare, alpha12_scare],1,2) alpha1_lure, alpha_1_lure];
            P_deactivation = X(5:8).*phi;

            TotProp = sum([P_noise P_interaction P_activation P_deactivation]);

            p_noise = P_noise/TotProp;
            p_interaction = P_interaction/TotProp;
            p_activation = P_activation/TotProp;
            p_deactivation = P_deactivation/TotProp;

            PT = cumsum([p_noise, p_interaction, p_activation, p_deactivation]);

            TotNoise = length(p_noise);
            TotInteraction = length(p_interaction);
            TotActivation = length(p_activation);
            TotDeactivation = length(P_deactivation);

            TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation, TotDeactivation]);

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                %disp('Noise')

                From = floor(Find_Reaction/3)+1;
                Mod = mod(Find_Reaction,3);
                if Mod == 0
                    From = From -1;
                    Mod = 3;
                end
                To = mod(From + Mod,4);

                if To == 0
                    To = 4;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                %disp('Interaction')



                Reaction = Find_Reaction - TotNoise;

                %% Use this block when self interaction is not valid. In that case, circular shift is necessary in the p_interaction step.

                %             From = floor(Reaction/7)+1;
                %
                %             Mod = mod(Reaction,7);
                %             if Mod == 0
                %                 From = From -1;
                %                 Mod = 7;
                %             end
                %
                %             To = mod(From + Mod,8);
                %%
                From = floor(Reaction/8)+1;

                Mod = mod(Reaction,8);
                if Mod == 0
                    From = From -1;
                end

                To = Mod;

                if To == 0
                    To = 4;
                end

                if To == 7
                    To = 3;
                end

                if To == 6
                    To = 2;
                end
                if To == 5
                    To = 1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation)

                %% Activation

                % Reactions = [16 17 18 27 28 25 35 36 45 46 15 26]

                %disp('Activation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                if Reaction <=6
                    From = floor(Reaction/3)+1;
                    Mod = mod(Reaction,3);
                    if Mod == 0
                        From = From -1;
                        Mod = 3;
                    end
                    To = mod(From + Mod,4);

                    if To == 0
                        To = 4;
                    end

                    To = To + 4;
                else

                    FromOptions = ceil(Reaction/2);


                    switch FromOptions
                        case 4
                            From = 3;
                        case 5
                            From = 4;
                        case 6
                            if Reaction == 11
                                From = 1;
                            else
                                From = 2;
                            end
                    end

                    if mod(Reaction,2) == 0
                        To = 6;
                    else
                        To = 5;
                    end
                end



            else
                %% Deactivation

                %disp('Deactivation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation);

                To = Reaction;
                From = Reaction + 4;

            end

            X(From) = X(From) -1;
            X(To) = X(To) + 1;

            Time(i) = (1/TotProp).*log(1/r1);

       

            Vertical_OP = X(1) - X(2);
            Horizontal_OP = X(3)-X(4);

            XT(i,:) = X;

            XVec(:,1) = X(1) * [1 0]';
            XVec(:,5) = X(5) * [1 0]';
            XVec(:,2) = X(2) * [-1 0]';
            XVec(:,6) = X(6) * [-1 0]';
            XVec(:,3) = X(3) * [0 1]';
            XVec(:,7) = X(7) * [0 1]';
            XVec(:,4) = X(4) * [0 -1]';
            XVec(:,8) = X(8) * [0 -1]';

            %% OP in horizontal direction calculation

            Xtop = X(1) + X(5);
            Xbottom = X(2) + X(6);
            Xright = X(3) + X(7);
            Xleft = X(4) + X(8);

  
           OPDirect_Herd(i) = Xtop/sum(X);

            OP(i,:) = sum(XVec,2);
            OPMag(i) = norm(OP(i,:))/sum(X);
            angleInRadians(i) = atan2(OP(i,2), OP(i,1));
            OPAngle(i) = rad2deg(angleInRadians(i));

            %OP(i) = abs(Horizontal_OP + sqrt(-1)*Vertical_OP)/sum(X);

        end

        %% Herding

        OPHerd_idx = find(OPDirect_Herd == 1);

        TimeHerd = Time(OPHerd_idx);

        OPHerd_idx = diff([OPHerd_idx -10000]);

        OPHerd_idx_idx = find(OPHerd_idx ~=1);

        if numel(OPHerd_idx_idx) == 0
            OPHerd(JJ,KK) = 0;
            OPHerd_Clusters = 0;
            cumulative_TimeHerd = 0;
            OPHerdTime(JJ,KK) = 0;
        else


        OPHerd(JJ,KK) = mean([OPHerd_idx_idx(1), diff(OPHerd_idx_idx)]);

        OPHerd_Clusters = [OPHerd_idx_idx(1), diff(OPHerd_idx_idx)];

        % Compute the cumulative sum of A
            
        cumulative_TimeHerd = cumsum(TimeHerd);

        % Use the indices in b to get the sums
        OPHerdTime(JJ,KK) = mean([diff(cumulative_TimeHerd(OPHerd_idx_idx))]);

        %cumulative_Time100(OP100_idx_idx(1)),

        end
        %
      

    end
end

File = 'Smooth_OPStay_Phi__10000';
save(File,"OPHerdTime");


% Save Figure

Yvalues  = 0.005:0.005:0.5;
Xvalues = 0.01:0.01:1;
figure;


    
         imagesc(OPHerd);
         colormap(navy_neongreen)
        set(gca, 'YDir','normal')
colorbar;

% Add axes labels
ylabel('Pressure (P)','FontSize',14);
xlabel('Lighness of the sheep','FontSize',14);
xticks(100:100:1000)
xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})

yticks(50:50:500)
yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})

% Set tick labels and tick values on the colorbar
c = colorbar;

% % Get the maximum and minimum values in the colorbar
% caxisValues = caxis;
% cmin = caxisValues(1);
% cmax = caxisValues(2);
% %c.Label.String = 'Colorbar Label';
% c.Ticks = [cmin cmax];
% c.TickLabels = {'DA', 'TA'};

% % Set tick values for x and y axes
%  xticks('auto');
% yticks([10 100 1000 10000]);
%
% % Set custom tick labels for x-axis
% yticklabels({'10^1','10^2', '10^3','10^4'});

% Set font size for all elements
set(gca, 'FontSize', 14);

% Save the image as SVG
saveas(gcf, 'OPStay_Phi__10000.svg', 'svg');

% Save the image as FIG
savefig('OPStay_Phi__10000.fig')



