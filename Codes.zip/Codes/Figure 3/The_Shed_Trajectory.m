
clear all
clc
%close all

PRESSURE = 1;

for KK = 1
    for Repeat = 1:1
        TotTime = 1000;

        AllData = zeros(TotTime*4,3);
        size(AllData)


        XT = zeros(TotTime,8);
        % Initial Orientations:
        x1 = 2; %Towards the dog
        x_1 = 1; %Towards the handler
        x2 = 1; %Towards East  
        x_2 = 1; %Towards West
        x3 = 0;
        x_3 = 0;
        x4 = 0;
        x_4 = 0;

        X = [x1, x_1, x2, x_2, x3, x_3, x4, x_4]; % 3 and -3 are direction in vertical direction and 4 and -4 are horizontal

        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.01;%Random switching

        alpha1_scare = 0; % Negative_reinforcement from the handler when the sheep is looking at the handler
        alpha_1_scare = PRESSURE*gamma; %Negative_reinforcement from the dog when the sheep is looking at the dog
        alpha12_scare = KK*alpha1_scare/10; % Negative_reinforcement from the handler if the sheep is looking perpendicular to the handler [alpha12_scare and alpha1_2_scare are same

        alpha_12_scare = KK*alpha_1_scare/10; % Negative_reinforcement from the dog if the sheep is looking perpendicular to the dog (same as alpha_1_2_scare)

        
        alpha1_lure = 0; % Unnecessary parameters for the herding problem. 
        alpha_1_lure = 0; % Unnecesary parameters for the herding problem

        phi = 10000  ; %Leader to follower transformation. It is related to the activation-deactivation problem described in the beginning of the code.



        for i = 1:TotTime


            %% propensities

            P_noise = repelem(X(1:4),1,3)*eps;

            P_interaction_matrix = gamma * X' * X;

            % IN the same direction, the pointer has to copy pointers other
            % than itself. So it shouod be x(x-1) on the diagonals

            diagInd = find(eye(size(P_interaction_matrix)));

            %             Replace diagonal elements with NaN

            Self_Mult = X.*(X-1);
            Self_Mult(Self_Mult<=0) = 0;

            P_interaction_matrix(diagInd) = Self_Mult'*gamma;

            P_interaction_matrix(5:8,:) = NaN; %Leaders don't follow anyone

            % Flatten the matrix
            P_interaction_matrix_Transpose = P_interaction_matrix';
            P_interaction_matrix_flat =  P_interaction_matrix_Transpose(:);

            % Remove NaN values
            P_interaction = P_interaction_matrix_flat(~isnan(P_interaction_matrix_flat))';

            P_activation = [repelem(X(1:2),1,3), repelem(X(3:4),1,2), X(1:2)].*[repelem([alpha1_scare, alpha_1_scare],1,3), repmat([alpha_12_scare, alpha12_scare],1,2) alpha1_lure, alpha_1_lure];
            P_deactivation = X(5:8).*phi;

            TotProp = sum([P_noise P_interaction P_activation P_deactivation]);

            p_noise = P_noise/TotProp;
            p_interaction = P_interaction/TotProp;
            p_activation = P_activation/TotProp;
            p_deactivation = P_deactivation/TotProp;

            PT = cumsum([p_noise, p_interaction, p_activation, p_deactivation]);

            TotNoise = length(p_noise);
            TotInteraction = length(p_interaction);
            TotActivation = length(p_activation);
            TotDeactivation = length(P_deactivation);

            TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation, TotDeactivation]);

            r1 = rand; % Random number that decides when the next update happens
            r2 = rand; % Random number that decides which update will happen

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                %disp('Noise')

                From = floor(Find_Reaction/3)+1;
                Mod = mod(Find_Reaction,3);
                if Mod == 0
                    From = From -1;
                    Mod = 3;
                end
                To = mod(From + Mod,4);

                if To == 0
                    To = 4;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                %disp('Interaction')

                Reaction = Find_Reaction - TotNoise;
                %%
                From = floor(Reaction/8)+1;

                Mod = mod(Reaction,8);
                if Mod == 0
                    From = From -1;
                end

                To = Mod;

                if To == 0
                    To = 4;
                end

                if To == 7
                    To = 3;
                end

                if To == 6
                    To = 2;
                end
                if To == 5
                    To = 1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation)

                %% Activation

                %disp('Activation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                if Reaction <=6
                    From = floor(Reaction/3)+1;
                    Mod = mod(Reaction,3);
                    if Mod == 0
                        From = From -1;
                        Mod = 3;
                    end
                    To = mod(From + Mod,4);

                    if To == 0
                        To = 4;
                    end

                    To = To + 4;
                else

                    FromOptions = ceil(Reaction/2);


                    switch FromOptions
                        case 4
                            From = 3;
                        case 5
                            From = 4;
                        case 6
                            if Reaction == 11
                                From = 1;
                            else
                                From = 2;
                            end
                    end

                    if mod(Reaction,2) == 0
                        To = 6;
                    else
                        To = 5;
                    end
                end



            else
                %% Deactivation

                %disp('Deactivation')

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation);

                To = Reaction;
                From = Reaction + 4;

            end

            X(From) = X(From) -1;
            X(To) = X(To) + 1;

            

            Time(i) = (1/TotProp).*log(1/r1);

            Vertical_OP = X(1) - X(2);
            Horizontal_OP = X(3)-X(4);

            XT(i,:) = X;

            XTot = XT(:,1:4) + XT(:,5:8);

            Xtop = X(1) + X(5);
            Xbottom = X(2) + X(6);
            Xright = X(3) + X(7);
            Xleft = X(4) + X(8);

            Xhor = Xright + Xleft;
            Xver = Xtop + Xbottom;

            if Xhor == 0
                Xhor = 1;
            end

            XRelHor = (Xhor - Xver)/sum(X);

            if XRelHor == 1

                OPDirect(i) = (abs(Xright-Xleft)/Xhor);
            else
                OPDirect(i) = -1;
            end
% 
%             if OPDirect(i) == 0.2
% 
%                 Shedding(Repeat) = sum(Time(1:i));
%                 break
%             end

        end
    end



    %csvwrite('ShedData.txt', AllData);


    %
    %plot((OP))
    %     xlabel('Time','FontSize',14)
    %     ylabel('Order Parameter','FontSize',14);
    %     set(gca, 'FontSize', 14);
    %     %xlim([0 4])
    %     % ylim([-.1 1.1])
    %     hold on
end

%mean(Shedding)

Time_r = repelem (cumsum(Time),2);
Time_r(1) = [];

XTot_r = repelem (XTot,2,1);
XTot_r(end,:) = [];


area(Time_r,XTot_r,'LineStyle','None')

% NewColor = [148,203,236
%     194,106,119
%     220,205,125
%     93,168,153];

colororder([0.580392156862745 0.796078431372549 0.925490196078431;0.76078431372549 0.415686274509804 0.466666666666667;0.862745098039216 0.803921568627451 0.490196078431373;0.364705882352941 0.658823529411765 0.6])

xlabel('Time (au)','FontSize',22)
ylabel('Sheep Count','FontSize',22)
%legend({'Direction 1','Direction 2','Direction 3', 'Direction 4'})
set(gca,"FontSize",16)
yticks([0.5 1.5 2.5 3.5 4.5])
yticklabels({'1','2','3','4','5'})
ylim([0,5])
yline([1:4])

%set(gcf,'position',[75,154.3333,900,400])

%legend boxoff
