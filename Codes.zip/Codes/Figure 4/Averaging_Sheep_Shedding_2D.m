%% This code is for averaging
clear all
clc
close all

halfWorld  = .5;


Size = 1;

NSheep = 5;

NoiseMag = 0.01;

TotTime = 10000;


XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

X = ones(1,NSheep);

Posn = [0.1*ones(1,NSheep);00*(1:NSheep)];

gamma = 10;%one-one intearction both leader-follower and follower-follower
eps = 10;%Random switching

alpha_Dog = 10; % Negative_reinforcement from the dog

alpha_handler = alpha_Dog;

Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

%% propensities

P_noise = eps.*X;

P_interaction_matrix = gamma * X' * X;

P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

% Flatten the matrix
P_interaction_matrix_Transpose = P_interaction_matrix';
P_interaction =  P_interaction_matrix_Transpose(:)';

P_activation_dog = alpha_Dog.*X;

P_activation_handler = alpha_handler.*X;

TotProp = sum([P_noise P_interaction P_activation_dog P_activation_handler]);

p_noise = P_noise/TotProp;
p_interaction = P_interaction/TotProp;
p_activation_dog = P_activation_dog/TotProp;
p_activation_handler = P_activation_handler/TotProp;

PT = cumsum([p_noise, p_interaction, p_activation_dog, p_activation_handler]);

TotNoise = length(p_noise);
TotInteraction = length(p_interaction);
TotActivation_dog = length(p_activation_dog);
TotActivation_hanler = length(p_activation_dog);



%TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation]);

Posn = 0.1*rand(2,NSheep);

for i = 1:TotTime


    [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

    Noise_Vec = (-1).^randi(100,2,NSheep).*rand(2,NSheep);

    Noise_Vec = Noise_Vec./sqrt(Noise_Vec(1,:).^2 + Noise_Vec(2,:).^2) ;

    Activation_Vec_dog = [ones(1,NSheep);zeros(1,NSheep)];

    Activation_Vec_handler = [-1*ones(1,NSheep);zeros(1,NSheep)];


    Averaging_Matrix_X = P_interaction_matrix .* XDirX' + P_noise'.*diag(Noise_Vec(1,:)) + P_activation_dog'.*diag(Activation_Vec_dog(1,:)) + P_activation_handler'.*diag(Activation_Vec_handler(1,:));
    NewDirX = mean(Averaging_Matrix_X);
    Averaging_Matrix_Y = P_interaction_matrix .* XDirY' + P_noise'.*diag(Noise_Vec(2,:)) + P_activation_dog'.*diag(Activation_Vec_dog(2,:)) + P_activation_handler'.*diag(Activation_Vec_handler(2,:));
    NewDirY = mean(Averaging_Matrix_Y);
    [NewAngle,~ ] = cart2pol(NewDirX,NewDirY);

    XDir = rem(NewAngle,2*pi);

    XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
    XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

    Time(i) = rand;
    Direction(i,:) = XDir;

    %% Finding shedding
    NegativeAngles = XDir(XDir<0);
    if numel(NegativeAngles) > 0
        NegativeAngles(NegativeAngles==-pi) = [];
    end
    PositiveAngles = XDir(XDir>0);
    if numel(PositiveAngles) > 0
        PositiveAngles(PositiveAngles == pi) = [];
    end

    TotAngles = length(PositiveAngles) + length(NegativeAngles);
    DiffAngles = abs(length(PositiveAngles) - length(NegativeAngles));

    if TotAngles == NSheep
        % if DiffAngles == 1
        OP_Positive(i) = (1/length(PositiveAngles)).*sum(exp(sqrt(-1)*PositiveAngles));
        OP_Negative(i) = (1/length(NegativeAngles)).*sum(exp(sqrt(-1)*NegativeAngles));
        OP_Total(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));
        
        Time_Spent = sum(Time(1:i)) - sum(Time(1:i-1));

        % end
    end

    Time_Spent = sum(Time(1:i)) - sum(Time(1:i-1));


    [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

    Posn = Posn + [XDirX;XDirY]*Time_Spent*0.01;


    OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));
    scatter(Posn(1,:),Posn(2,:),20,'filled');
    hold on
    scatter(Posn(1,:),Posn(2,:),20,'filled','MarkerEdgeColor',[0.8500 0.3250 0.0980],...
        'MarkerFaceColor',[0.8500 0.3250 0.0980]);
    hold on
    hq = quiver(Posn(1,:),Posn(2,:),0.05*XDirX,0.05*XDirY,0,'-k', 'ShowArrowHead', 'off');
    U = hq.UData;
    V = hq.VData;
    X = hq.XData;
    Y = hq.YData;


    for ii = 1:length(X)
        %  for ij = 1:length(X)

        headWidth = 10;
        ah = annotation('arrow',...
            'headStyle','hypocycloid','HeadWidth',headWidth);
        set(ah,'parent',gca);
        set(ah,'position',[X(ii) Y(ii) U(ii) V(ii)]);

        % end
    end

    xlim([-halfWorld, halfWorld]);
    ylim([-halfWorld, halfWorld]);
    hold off


    pause(0.1)

end



