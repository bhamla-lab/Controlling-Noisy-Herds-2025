%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

halfWorld  = .2;


Size = 1;

NSheep = 5;

NoiseMag = 0.01;

TotTime = 10000;


XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

X = ones(1,NSheep);



% parameters
gamma = 10;%one-one intearction both leader-follower and follower-follower
eps = 10;%Random switching

alpha = 10 ; % Negative_reinforcement from the dog

Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

%% propensities

P_noise = eps.*X;

P_interaction_matrix = gamma * X' * X;

P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

% Flatten the matrix
P_interaction_matrix_Transpose = P_interaction_matrix';
P_interaction =  P_interaction_matrix_Transpose(:)';


P_activation = alpha.*X;

TotProp = sum([P_noise P_interaction P_activation]);

p_noise = P_noise/TotProp;
p_interaction = P_interaction/TotProp;
p_activation = P_activation/TotProp;

PT = cumsum([p_noise, p_interaction, p_activation]);

TotNoise = length(p_noise);
TotInteraction = length(p_interaction);
TotActivation = length(p_activation);


TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation]);

Posn = 0.1*[-.5*ones(1,NSheep);0.1*(1:NSheep)];

for i = 1:TotTime

    Flag = 0;

    r1 = rand;
    r2 = rand;

    Find_Reaction = find((PT-r2)>0);
    Find_Reaction = Find_Reaction(1);

    % Use a switch case statement

    if Find_Reaction <= TotNoise

        Flag = 1;

        Reaction = Find_Reaction;

        Switching = mod(Reaction,NSheep);

        if Switching == 0
            Switching = NSheep;
        end

    elseif Find_Reaction <= (TotNoise + TotInteraction)

        Flag = 2;

        Reaction = Find_Reaction - TotNoise;

        Switching = mod(Reaction,NSheep);

        Following = floor(Reaction/NSheep) + 1;

        if Switching == 0
            Switching = NSheep;
            Following = Following -1;
        end

    else
        Flag = 3;

        Reaction = Find_Reaction - (TotNoise + TotInteraction);

        Switching = mod(Reaction,NSheep);

        if Switching == 0
            Switching = NSheep;
        end
    end

    %% Update rules
    if Flag == 1

        DelTheta = 2*pi*rand;

        XDir(Switching) = XDir(Switching) + DelTheta;

    elseif Flag == 2

        XDir(Switching) = XDir(Following);
    else
        if XDir(Switching) == pi
            NewDir = ((-1)^randi(100))* rand* Dog_Scare_Theta;
        else
            NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;
        end

        XDir(Switching) = NewDir;

    end

    XDir = rem(XDir,2*pi);


    XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
    XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

    Time(i) = (1/TotProp).*log(1/r1);

    if i>1
        OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));

        %if abs(OP(i)) > 0.95 && abs(angle(OP(i))) < pi/100

        Time_Spent = sum(Time(1:i)) - sum(Time(1:i-1));
        %else
        %     Time_Spent = 0;
        %  end

        [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

        Posn = Posn + [XDirX;XDirY]*Time_Spent;


        OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));
        scatter(Posn(1,:),Posn(2,:),20,'filled');
        hold on
        scatter(Posn(1,:),Posn(2,:),20,'filled','MarkerEdgeColor',[0.8500 0.3250 0.0980],...
            'MarkerFaceColor',[0.8500 0.3250 0.0980]);
        hold on
        hq = quiver(Posn(1,:),Posn(2,:),0.05*XDirX,0.05*XDirY,'k','ShowArrowHead', 'off');
        U = hq.UData;
        V = hq.VData;
        X = hq.XData;
        Y = hq.YData;


        for ii = 1:length(X)
            %  for ij = 1:length(X)

            headWidth = 10;
            ah = annotation('arrow',...
                'headStyle','hypocycloid','HeadWidth',headWidth);
            set(ah,'parent',gca);
            set(ah,'position',[X(ii) Y(ii) U(ii) V(ii)]);

            % end
        end

        xlim([-halfWorld, halfWorld]);
        ylim([-halfWorld, halfWorld]);
        hold off


        pause(0.1)
    end
end

