
%% This code implements Gillespie's algorithm to solve the 2D herding problem For N directions.

clear all
clc
close all

NSheep = 5;

%NoiseMag = 0.01;

halfWorld  = .2; % Half world of the arena

TotTime = 1000;
Time_Spent = 0.00;

XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

X = ones(1,NSheep);

Posn = 0.1*[-1.5*ones(1,NSheep);0.1*(1:NSheep)]; % Initial Position


% parameters
gamma = .010;%one-one intearction both leader-follower and follower-follower
eps = .008;%Random switching

alpha = .0100 ; % Negative_reinforcement from the dog

Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

%% propensities

P_noise = eps.*X; 

P_interaction_matrix = gamma * X' * X;

P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

P_activation = alpha.*X;


for i = 1:TotTime


    [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

    Noise_Vec = (-1).^randi(100,2,NSheep).*rand(2,NSheep);

    Noise_Vec = Noise_Vec./sqrt(Noise_Vec(1,:).^2 + Noise_Vec(2,:).^2) ;

    Activation_Vec = [ones(1,NSheep);zeros(1,NSheep)];


    Averaging_Matrix_X = P_interaction_matrix .* XDirX' + P_noise'.*diag(Noise_Vec(1,:)) + P_activation'.*diag(Activation_Vec(1,:));
    NewDirX = mean(Averaging_Matrix_X);
    Averaging_Matrix_Y = P_interaction_matrix .* XDirY' + P_noise'.*diag(Noise_Vec(2,:)) + P_activation'.*diag(Activation_Vec(2,:));
    NewDirY = mean(Averaging_Matrix_Y);

    Posn = Posn + [NewDirX;NewDirY].*Time_Spent;

    [NewAngle,~ ] = cart2pol(NewDirX,NewDirY) ;

    XDir = rem(NewAngle,2*pi);

    XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
    XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

    %Time(i) = rand;

    OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));
          
    Time_Spent = rand;

    scatter(Posn(1,:),Posn(2,:),20,'filled','MarkerEdgeColor',[0.8500 0.3250 0.0980],...
              'MarkerFaceColor',[0.8500 0.3250 0.0980]);
    hold on
    hq = quiver(Posn(1,:),Posn(2,:),0.05*XDirX,0.05*XDirY,'off','-k');
    U = hq.UData;
    V = hq.VData;
    X = hq.XData;
    Y = hq.YData;
    
    for ii = 1:length(X)
  %  for ij = 1:length(X)

        headWidth = 10;
        ah = annotation('arrow',...
            'headStyle','hypocycloid','HeadWidth',headWidth);
        set(ah,'parent',gca);
        set(ah,'position',[X(ii) Y(ii) U(ii) V(ii)]);

   % end
    end

xlim([-halfWorld, halfWorld]);
ylim([-halfWorld, halfWorld]);
   hold off


pause(0.1)

end



