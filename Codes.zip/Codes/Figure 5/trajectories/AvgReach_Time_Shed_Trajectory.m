%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

%%

Size = 1;

NSheep = 5;

%NoiseMag = 0.01;

for AA = 1:1 %Noise magnitude
    AA

for JJ = 1:1 %Pressure
    
    for KK = 1:1

        

        TotTime = 50;


        XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep)

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
       eps = 0.1*AA;%Random switching

       alpha_Dog = JJ*.1; % Negative_reinforcement from the dog

        alpha_handler = JJ*0.1;


        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        P_activation_dog = alpha_Dog.*X;

        P_activation_handler = alpha_handler.*X;

        for i = 1:TotTime


                [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

                Noise_Vec = (-1).^randi(100,2,NSheep).*rand(2,NSheep);

                Noise_Vec = Noise_Vec./sqrt(Noise_Vec(1,:).^2 + Noise_Vec(2,:).^2) ;

                Activation_Vec_dog = [ones(1,NSheep);zeros(1,NSheep)];

                Activation_Vec_handler = [-1*ones(1,NSheep);zeros(1,NSheep)];


                Averaging_Matrix_X = P_interaction_matrix .* XDirX' + P_noise'.*diag(Noise_Vec(1,:)) + P_activation_dog'.*diag(Activation_Vec_dog(1,:)) + P_activation_handler'.*diag(Activation_Vec_handler(1,:));
                NewDirX = mean(Averaging_Matrix_X);
                Averaging_Matrix_Y = P_interaction_matrix .* XDirY' + P_noise'.*diag(Noise_Vec(2,:)) + P_activation_dog'.*diag(Activation_Vec_dog(2,:)) + P_activation_handler'.*diag(Activation_Vec_handler(2,:));
                NewDirY = mean(Averaging_Matrix_Y);
                [NewAngle,~ ] = cart2pol(NewDirX,NewDirY);

                XDir = rem(NewAngle,2*pi);

                XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
                XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

                Time(i) = rand;
                Direction(i,:) = XDir;

                %% Finding shedding
            NegativeAngles = XDir(XDir<0);
            if numel(NegativeAngles) > 0
            NegativeAngles(NegativeAngles==-pi) = [];
            end
            PositiveAngles = XDir(XDir>0);
            if numel(PositiveAngles) > 0
            PositiveAngles(PositiveAngles == pi) = [];
            end

            TotAngles = length(PositiveAngles) + length(NegativeAngles);
            DiffAngles = abs(length(PositiveAngles) - length(NegativeAngles));

            if TotAngles == NSheep
                if DiffAngles == 1
                    OP_Positive(i) = (1/length(PositiveAngles)).*sum(exp(sqrt(-1)*PositiveAngles));
                    OP_Negative(i) = (1/length(NegativeAngles)).*sum(exp(sqrt(-1)*NegativeAngles));
                    OP_Total(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));
                    if abs(OP_Positive(i)) > 0.99  && abs(OP_Negative(i)) > 0.99 && abs(OP_Total(i)) < 0.9
                        ReachTime(KK) = sum(Time(1:i));
                       
                        break;
                    end
                end
            end

        end
        

        if i == TotTime
            ReachTime(KK) = sum(Time);
        end
    end
    
    AvgReachShed(AA,JJ) = mean(ReachTime);
    clear ReachTime;
end

end

TotDirection = repelem(Direction,round(Time*1000),1);
imagesc(TotDirection')
jet_wrap = vertcat(pink,flipud(bone));
colormap(jet_wrap);
caxis([-pi, pi]);
yline([1.5:4.5])

%plot(AvgReach)

% save("Average_ReachDynamics_Shed_500_500.mat","AvgReachShed");