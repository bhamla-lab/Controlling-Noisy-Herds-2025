%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all



%%

Size = 1;

NSheep = 5;

NoiseMag = 0.01;

for AA = 1:1 %Noise magnitude
AA
for JJ = 1:1 %Pressure
    
    for KK = 1:1

        

        TotTime = 200;


        XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.1*AA;%Random switching

        alpha = JJ*1 ; % Negative_reinforcement from the dog

        Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        % Flatten the matrix
        P_interaction_matrix_Transpose = P_interaction_matrix';
        P_interaction =  P_interaction_matrix_Transpose(:)';


        P_activation = alpha.*X;

        TotProp = sum([P_noise P_interaction P_activation]);

        p_noise = P_noise/TotProp;
        p_interaction = P_interaction/TotProp;
        p_activation = P_activation/TotProp;

        PT = cumsum([p_noise, p_interaction, p_activation]);

        TotNoise = length(p_noise);
        TotInteraction = length(p_interaction);
        TotActivation = length(p_activation);


        TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation]);


        for i = 1:TotTime

            Flag = 0;

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                Flag = 1;

                Reaction = Find_Reaction;

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                Flag = 2;

                Reaction = Find_Reaction - TotNoise;

                Switching = mod(Reaction,NSheep);

                Following = floor(Reaction/NSheep) + 1;

                if Switching == 0
                    Switching = NSheep;
                    Following = Following -1;
                end

            else
                Flag = 3;

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end
            end

            %% Update rules
            if Flag == 1

                DelTheta = 2*pi*rand;

                XDir(Switching) = XDir(Switching) + DelTheta;

            elseif Flag == 2

                XDir(Switching) = XDir(Following);
            else 

                if XDir(Switching) == pi
            NewDir = ((-1)^randi(100))* rand* Dog_Scare_Theta;
        else
            NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;
        end

                XDir(Switching) = NewDir;

            end

            XDir = rem(XDir,2*pi);


            XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
            XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

            Time(i) = (1/TotProp).*log(1/r1);

            Direction(i,:) = XDir;

             VarDir(i) = std(XDir);

            OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));

         
        end

        if i == TotTime
            ReachTime(KK) = sum(Time);
        end
    end
    Reach(AA,JJ) = mean(ReachTime);
    clear ReachTime;
end
end

TotDirection = repelem(Direction,round(Time*1000),1);
imagesc(TotDirection')
jet_wrap = vertcat(pink,flipud(bone));
colormap(jet_wrap);
caxis([-pi, pi]);
yline([1.5:4.5])

 