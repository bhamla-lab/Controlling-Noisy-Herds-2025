%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

%% Colormap

% Define the RGB values for navy blue, neon green, and yellow
navy_blue = [0, 0, 128] / 255;  % RGB for navy blue
neon_green = [57, 255, 20] / 255;  % RGB for neon green
yellow = [255, 255, 0] / 255;  % RGB for yellow

% Create a colormap with a smooth transition from blue to green to yellow
color_map = [linspace(navy_blue(1), neon_green(1), 128), ...
    linspace(neon_green(1), yellow(1), 128); ...
    linspace(navy_blue(2), neon_green(2), 128), ...
    linspace(neon_green(2), yellow(2), 128); ...
    linspace(navy_blue(3), neon_green(3), 128), ...
    linspace(neon_green(3), yellow(3), 128)]';

%%

Size = 1;

NSheep = 5;

%NoiseMag = 0.01;

for AA = 1:1 %Noise magnitude
    AA

for JJ = 1:1 %Pressure
    
    for KK = 1:1

        

        TotTime = 100;


        XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
       eps = .1*AA;%Random switching

        alpha = 0.1*JJ ; % Negative_reinforcement from the dog


        Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        P_activation = alpha.*X;
        

        for i = 1:TotTime


                [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

                Noise_Vec = (-1).^randi(100,2,NSheep).*rand(2,NSheep);

                Noise_Vec = Noise_Vec./sqrt(Noise_Vec(1,:).^2 + Noise_Vec(2,:).^2) ;

                Activation_Vec = [ones(1,NSheep);zeros(1,NSheep)];


                Averaging_Matrix_X = P_interaction_matrix .* XDirX' + P_noise'.*diag(Noise_Vec(1,:)) + P_activation'.*diag(Activation_Vec(1,:));
                NewDirX = mean(Averaging_Matrix_X);
                Averaging_Matrix_Y = P_interaction_matrix .* XDirY' + P_noise'.*diag(Noise_Vec(2,:)) + P_activation'.*diag(Activation_Vec(2,:));
                NewDirY = mean(Averaging_Matrix_Y);
                [NewAngle,~ ] = cart2pol(NewDirX,NewDirY) ;

                XDir = rem(NewAngle,2*pi);

                XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
                XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

                Time(i) = rand;

                OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));


                if abs(OP(i)) > 0.99 && abs(angle(OP(i))) < pi/200
                    ReachTime(KK) = sum(Time(1:i));
                 
                end
  Direction(i,:) = XDir;
        end
        

        if i == TotTime
            ReachTime(KK) = sum(Time);
        end
    end
    
    AvgReach(AA,JJ) = mean(ReachTime);
    clear ReachTime;
end

end

TotDirection = repelem(Direction,round(Time*1000),1);
imagesc(TotDirection')
jet_wrap = vertcat(pink,flipud(bone));
colormap(jet_wrap);
caxis([-pi, pi]);
yline([1.5:4.5])

%plot(AvgReach)
