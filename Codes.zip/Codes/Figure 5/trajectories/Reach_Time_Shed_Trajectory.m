%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

%%

Size = 1;

NSheep = 5;

NoiseMag = 0.1;

for AA = 1:1 %Noise magnitude
AA
for JJ = 1:1 %Pressure
    
    for KK = 1:1

        

        TotTime = 100;


        XDir = ((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.1*AA;%Random switching

        alpha_Dog = JJ*.1; % Negative_reinforcement from the dog

        alpha_handler = JJ*.1;

        Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        % Flatten the matrix
        P_interaction_matrix_Transpose = P_interaction_matrix';
        P_interaction =  P_interaction_matrix_Transpose(:)';


        P_activation_Dog = alpha_Dog.*X;

        P_activation_handler = alpha_handler.*X;

        TotProp = sum([P_noise P_interaction P_activation_Dog P_activation_handler]);

        p_noise = P_noise/TotProp;
        p_interaction = P_interaction/TotProp;
        p_activation_dog = P_activation_Dog/TotProp;
        p_activation_handler = P_activation_handler/TotProp;

        PT = cumsum([p_noise, p_interaction, p_activation_dog, p_activation_handler]);

        TotNoise = length(p_noise);
        TotInteraction = length(p_interaction);
        TotActivation_dog = length(p_activation_dog);
        TotActivation_hanler = length(p_activation_dog);


        TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation_dog, TotActivation_hanler]);


        for i = 1:TotTime

            Flag = 0;

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                Flag = 1;

                Reaction = Find_Reaction;

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                Flag = 2;

                Reaction = Find_Reaction - TotNoise;

                Switching = mod(Reaction,NSheep);

                Following = floor(Reaction/NSheep) + 1;

                if Switching == 0
                    Switching = NSheep;
                    Following = Following -1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation_dog)
                Flag = 3;

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            else
                Flag = 4;

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation_dog);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end
            end

            %% Update rules
            if Flag == 1

                DelTheta = 2*pi*rand;

                XDir(Switching) = XDir(Switching) + DelTheta;

            elseif Flag == 2

                XDir(Switching) = XDir(Following);

            elseif Flag == 3
                if XDir(Switching) == pi
                    NewDir = ((-1)^randi(100))* rand* Dog_Scare_Theta;
                else
                    NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;
                end
                %NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;

                XDir(Switching) = NewDir;

            else

                if XDir(Switching) == 0
                    NewDir = ((-1)^randi(100))* rand* Dog_Scare_Theta;
                else
                    NewDir = pi;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;
                end
                %NewDir = pi;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;

                XDir(Switching) = NewDir;

            end

            XDir = rem(XDir,2*pi);


            XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
            XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

            Time(i) = (1/TotProp).*log(1/r1);

            Direction(i,:) = XDir;

             VarDir(i) = std(XDir);

            

            %% Finding shedding
            NegativeAngles = XDir(XDir<0);
            if numel(NegativeAngles) > 0
            NegativeAngles(NegativeAngles==-pi) = [];
            end
            PositiveAngles = XDir(XDir>0);
            if numel(PositiveAngles) > 0
            PositiveAngles(PositiveAngles == pi) = [];
            end

            TotAngles = length(PositiveAngles) + length(NegativeAngles);
            DiffAngles = abs(length(PositiveAngles) - length(NegativeAngles));

            if TotAngles == NSheep
                if DiffAngles == 1
                    OP_Positive(i) = (1/length(PositiveAngles)).*sum(exp(sqrt(-1)*PositiveAngles));
                    OP_Negative(i) = (1/length(NegativeAngles)).*sum(exp(sqrt(-1)*NegativeAngles));
                     OP_Total(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));

                    if abs(OP_Positive(i)) > 0.99  && abs(OP_Negative(i)) > 0.99 && abs(OP_Total(i)) < 0.9 
                        ReachTime(KK) = sum(Time(1:i));
                        Start = i
                    end

                end
            end
    
        end

        if i == TotTime
            i
            ReachTime(KK) = sum(Time)
        end
    end
    Reach_Shed(AA,JJ) = mean(ReachTime);
    clear ReachTime;
end
end





TotDirection = repelem(Direction,round(Time*1000),1);
imagesc(TotDirection')
jet_wrap = vertcat(pink,flipud(bone));
colormap(jet_wrap);
caxis([-pi, pi]);
yline([1.5:4.5])

 %save("ReachDynamics_Shed_500_500.mat","Reach_Shed");