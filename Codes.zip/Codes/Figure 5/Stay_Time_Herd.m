%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

%% Colormap

% Define the RGB values for navy blue, neon green, and yellow
navy_blue = [0, 0, 128] / 255;  % RGB for navy blue
neon_green = [57, 255, 20] / 255;  % RGB for neon green
yellow = [255, 255, 0] / 255;  % RGB for yellow

% Create a colormap with a smooth transition from blue to green to yellow
color_map = [linspace(navy_blue(1), neon_green(1), 128), ...
    linspace(neon_green(1), yellow(1), 128); ...
    linspace(navy_blue(2), neon_green(2), 128), ...
    linspace(neon_green(2), yellow(2), 128); ...
    linspace(navy_blue(3), neon_green(3), 128), ...
    linspace(neon_green(3), yellow(3), 128)]';

%%

Size = 1;

NSheep = 5;

NoiseMag = 0.01;

for AA = 1:500

    AA

for JJ = 1:500
    
    for KK = 1:100

        Reached_Flag = 0;

        TotTime = 100;


        XDir = zeros(1,NSheep);%((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
       eps = 0.0002*AA;%Random switching

        alpha = JJ*0.002 ; % Negative_reinforcement from the dog


        Dog_Scare_Theta = pi;

        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        % Flatten the matrix
        P_interaction_matrix_Transpose = P_interaction_matrix';
        P_interaction =  P_interaction_matrix_Transpose(:)';


        P_activation = alpha.*X;

        TotProp = sum([P_noise P_interaction P_activation]);

        p_noise = P_noise/TotProp;
        p_interaction = P_interaction/TotProp;
        p_activation = P_activation/TotProp;

        PT = cumsum([p_noise, p_interaction, p_activation]);

        TotNoise = length(p_noise);
        TotInteraction = length(p_interaction);
        TotActivation = length(p_activation);


        TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation]);


        for i = 1:TotTime

          

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                Flag = 1;

                Reaction = Find_Reaction;

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                Flag = 2;

                Reaction = Find_Reaction - TotNoise;

                Switching = mod(Reaction,NSheep);

                Following = floor(Reaction/NSheep) + 1;

                if Switching == 0
                    Switching = NSheep;
                    Following = Following -1;
                end

            else
                Flag = 3;

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end
            end

            %% Update rules
            if Flag == 1

                DelTheta = 2*pi*rand;

                XDir(Switching) = XDir(Switching) + DelTheta;

            elseif Flag == 2

                XDir(Switching) = XDir(Following);
            else
                NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;

                XDir(Switching) = NewDir;

            end

            XDir = rem(XDir,2*pi);


            XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
            XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

            Time(i) = (1/TotProp).*log(1/r1);

            Direction(i,:) = XDir;

             VarDir(i) = std(XDir);

            OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));


            if abs(OP(i)) < 0.99 || abs(angle(OP(i))) > pi/200
                StayTime(KK) = sum(Time(1:i));
                break;
            end

        end

        if i == TotTime
            StayTime(KK) = 50;
        end

    end
     Stay(AA,JJ) = mean(StayTime);
     clear StayTime;
end
end

save("StayDynamics_Herd_500_500.mat","Stay");

% save("StayDynamics.mat","Stay");
% 
% imagesc(Stay);
%         colormap(navy_neongreen)
%         set(gca, 'YDir','normal')
% colorbar;
% 
% % Add axes labels
% ylabel('Pressure','FontSize',14);
% xlabel('Panic','FontSize',14);
% xticks(10:10:100)
% xticklabels({'0.1', '0.2', '0.3', '0.4','0.5','0.6','0.7','0.8','0.9','1'})
% 
% yticks(10:10:100)
% yticklabels({'0.5', '1', '1.5', '2','2.5','3','3.5','4','4.5','5'})
% 
% % Save the image as SVG
% saveas(gcf, 'Cont_Panic.svg', 'svg');
% 
% % Save the image as FIG
% savefig('Cont_Panic.fig')
% 
