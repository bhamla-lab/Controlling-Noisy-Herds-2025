clear all
%close all
PhaseColorMap = [118,150,142
193,103,103];

PhaseColorMap = PhaseColorMap./255;

load('Average_ReachDynamics_Herd_500_500.mat')
load('Average_StayDynamics_Herd_500_500.mat')
load('ReachDynamics_Herd_500_500.mat')
load('StayDynamics_Herd_500_500.mat')
%load('New_Model_ReachDynamics_Herd_500_500')

% Stay = table2array(load('StayDynamics_Herd_500_500.mat'));
% Reach = load('ReachDynamics_Herd_500_500.mat');
% 
% AvgStay = load('Average_StayDynamics_Herd_500_500.mat');
% AvgReach = load('Average_ReachDynamics_Herd_500_500.mat');

Eh = Stay./Reach;

EhAvg = AvgStay./AvgReach;
Compare = zeros(size(Eh,1), size(Eh,2));
Compare(Eh>EhAvg) = 10;
Compare(Eh==EhAvg) = 5;
figure;
imagesc(Compare);
set(gca, 'YDir','normal')
colormap(copper)

xlim([25,500])

xticks(50:50:500)
xticklabels({'1', '2', '3', '4','5','6','7','8','9','10'})

yticks(100:100:500)
yticklabels({'0.2',  '0.4','0.6','0.8','1'})

%Add axes labels
xlabel('Pressure \alpha/\gamma','FontSize',16);
ylabel('Noise Strength \epsilon/\gamma','FontSize',16);
set(gca, 'FontSize', 16);



% Set tick labels and tick values on the colorbar

% % Get the maximum and minimum values in the colorbar
% caxisValues = caxis;
% cmin = caxisValues(1);
% cmax = caxisValues(2);
% %c.Label.String = 'Colorbar Label';
% c.Ticks = [cmin cmax];
% c.TickLabels = {'DA', 'TA'};

% % Set tick values for x and y axes
%  xticks('auto');
% yticks([10 100 1000 10000]);
%
% % Set custom tick labels for x-axis
% yticklabels({'10^1','10^2', '10^3','10^4'});


% Save the image as FIG
%savefig('Shed_phase_diagram_OP100_Better_OP_Calc_Phi_0.05.fig')


