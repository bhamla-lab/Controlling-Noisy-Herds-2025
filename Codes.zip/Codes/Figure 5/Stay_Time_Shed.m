%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all

%% Colormap

% Define the RGB values for navy blue, neon green, and yellow
navy_blue = [0, 0, 128] / 255;  % RGB for navy blue
neon_green = [57, 255, 20] / 255;  % RGB for neon green
yellow = [255, 255, 0] / 255;  % RGB for yellow

% Create a colormap with a smooth transition from blue to green to yellow
color_map = [linspace(navy_blue(1), neon_green(1), 128), ...
    linspace(neon_green(1), yellow(1), 128); ...
    linspace(navy_blue(2), neon_green(2), 128), ...
    linspace(neon_green(2), yellow(2), 128); ...
    linspace(navy_blue(3), neon_green(3), 128), ...
    linspace(neon_green(3), yellow(3), 128)]';

%%

Size = 1;

NSheep = 5;

NoiseMag = 0.01;

for AA = 1:500 %Noise magnitude
AA
for JJ = 1:500 %Pressure
    
    for KK = 1:100

        

        TotTime = 100;

            NegAngle = -1.*ones(1,3).*pi.*rand;
            PosAngle = ones(1,2).*pi.*rand;
           
        XDir = [PosAngle, NegAngle];

        X = ones(1,NSheep);



        % parameters
        gamma = .1;%one-one intearction both leader-follower and follower-follower
        eps = 0.0002*AA;%Random switching

        alpha_Dog = JJ*0.0002; % Negative_reinforcement from the dog

        alpha_handler = JJ*0.0002;


        %% propensities

        P_noise = eps.*X;

        P_interaction_matrix = gamma * X' * X;

        P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

        % Flatten the matrix
        P_interaction_matrix_Transpose = P_interaction_matrix';
        P_interaction =  P_interaction_matrix_Transpose(:)';


        P_activation_Dog = alpha_Dog.*X;

        P_activation_handler = alpha_handler.*X;

        TotProp = sum([P_noise P_interaction P_activation_Dog P_activation_handler]);

        p_noise = P_noise/TotProp;
        p_interaction = P_interaction/TotProp;
        p_activation_dog = P_activation_Dog/TotProp;
        p_activation_handler = P_activation_handler/TotProp;

        PT = cumsum([p_noise, p_interaction, p_activation_dog, p_activation_handler]);

        TotNoise = length(p_noise);
        TotInteraction = length(p_interaction);
        TotActivation_dog = length(p_activation_dog);
        TotActivation_hanler = length(p_activation_dog);


        TotCumsum = cumsum([TotNoise, TotInteraction, TotActivation_dog, TotActivation_hanler]);


        for i = 1:TotTime

            Flag = 0;

            r1 = rand;
            r2 = rand;

            Find_Reaction = find((PT-r2)>0);
            Find_Reaction = Find_Reaction(1);

            % Use a switch case statement

            if Find_Reaction <= TotNoise

                Flag = 1;

                Reaction = Find_Reaction;

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction)

                Flag = 2;

                Reaction = Find_Reaction - TotNoise;

                Switching = mod(Reaction,NSheep);

                Following = floor(Reaction/NSheep) + 1;

                if Switching == 0
                    Switching = NSheep;
                    Following = Following -1;
                end

            elseif Find_Reaction <= (TotNoise + TotInteraction + TotActivation_dog)
                Flag = 3;

                Reaction = Find_Reaction - (TotNoise + TotInteraction);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end

            else
                Flag = 4;

                Reaction = Find_Reaction - (TotNoise + TotInteraction + TotActivation_dog);

                Switching = mod(Reaction,NSheep);

                if Switching == 0
                    Switching = NSheep;
                end
            end

            %% Update rules
            if Flag == 1

                DelTheta = 2*pi*rand;

                XDir(Switching) = XDir(Switching) + DelTheta;

            elseif Flag == 2

                XDir(Switching) = XDir(Following);

            elseif Flag == 3
                NewDir = 0;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;

                XDir(Switching) = NewDir;

            else
                NewDir = pi;%((-1)^randi(100))* rand* Dog_Scare_Theta/2;

                XDir(Switching) = NewDir;

            end

            XDir = rem(XDir,2*pi);


            XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
            XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

            Time(i) = (1/TotProp).*log(1/r1);

            Direction(i,:) = XDir;

             VarDir(i) = std(XDir);

            

            %% Finding shedding
            NegativeAngles = XDir(XDir<0);
            if numel(NegativeAngles) > 0
            NegativeAngles(NegativeAngles==-pi) = [];
            end
            PositiveAngles = XDir(XDir>0);
            if numel(PositiveAngles) > 0
            PositiveAngles(PositiveAngles == pi) = [];
            end

            TotAngles = length(PositiveAngles) + length(NegativeAngles);
            DiffAngles = abs(length(PositiveAngles) - length(NegativeAngles));

            StopLoop = 0; %Find where stay has ended and loop needs to stop

            if TotAngles ~= NSheep
                StopLoop = 1;
            else
                if DiffAngles ~= 1
                    StopLoop = 1;
                else

                    OP_Positive(i) = (1/length(PositiveAngles)).*sum(exp(sqrt(-1)*PositiveAngles));
                    OP_Negative(i) = (1/length(NegativeAngles)).*sum(exp(sqrt(-1)*NegativeAngles));

                    if abs(OP_Positive(i)) < 0.99  || abs(OP_Negative(i)) < 0.99 
                        StayTime(KK) = sum(Time(1:i));
                        break;
                    end
                end
            end
            if StopLoop == 1
                StayTime(KK) = sum(Time(1:i));
                        break;
            end
    
        end

        if i == TotTime
            StayTime(KK) = sum(Time);
        end
    end
   Stay_Shed(AA,JJ) = mean(StayTime);
    clear StayTime;
end
end

 save("StayDynamics_Shed_500_500.mat","Stay_Shed");