%% 9/21 This code simulates (SSA) Shed problem the switching dynamics of the herd of 1d agents in presence of active agents. This simulation ignores the AAA model and assumes that the agents are always inside the alignment radius of each other.

%% This code implements Gillespie's algorithm to solve the 1D herding problem For N directions.
%% 9/25:This code simulates the continuous version
clear all
clc
close all


%%

Size = 1;

NSheep = 5;

NoiseMag = 0.01;

%Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.




for AA = 1:500 %Noise magnitude
    AA

    for JJ = 1:500 %Pressure

        for KK = 1:500



            TotTime = 100;


            XDir = zeros(1,NSheep);%((-1).^randi(100,1,NSheep)).*pi.*rand(1,NSheep);

            X = ones(1,NSheep);



            % parameters
            gamma = .1;%one-one intearction both leader-follower and follower-follower
            eps = .0002*AA;%Random switching

            alpha = 0.002*JJ ; % Negative_reinforcement from the dog


            Dog_Scare_Theta = pi; %Dog is at pi. So the scared sheep will move away from dog in -pi/2 to pi/2. Herding direction is 0.

            %% propensities

            P_noise = eps.*X;

            P_interaction_matrix = gamma * X' * X;

            P_interaction_matrix = P_interaction_matrix - diag(diag(P_interaction_matrix));

            P_activation = alpha.*X;
            

            for i = 1:TotTime


                [XDirX , XDirY] = pol2cart(XDir,ones(1,NSheep));

                Noise_Vec = (-1).^randi(100,2,NSheep).*rand(2,NSheep);

                Noise_Vec = Noise_Vec./sqrt(Noise_Vec(1,:).^2 + Noise_Vec(2,:).^2) ;

                Activation_Vec = [ones(1,NSheep);zeros(1,NSheep)];


                Averaging_Matrix_X = P_interaction_matrix .* XDirX' + P_noise'.*diag(Noise_Vec(1,:)) + P_activation'.*diag(Activation_Vec(1,:));
                NewDirX = mean(Averaging_Matrix_X);
                Averaging_Matrix_Y = P_interaction_matrix .* XDirY' + P_noise'.*diag(Noise_Vec(2,:)) + P_activation'.*diag(Activation_Vec(2,:));
                NewDirY = mean(Averaging_Matrix_Y);
                [NewAngle,~ ] = cart2pol(NewDirX,NewDirY) ;

                XDir = rem(NewAngle,2*pi);

                XDir(XDir>pi) = XDir(XDir>pi) - 2*pi;
                XDir(XDir<-pi) = XDir(XDir<-pi) + 2*pi;

                Time(i) = rand;

                %Direction(i,:) = XDir;

                VarDir(i) = std(XDir);

                OP(i) = (1/NSheep).*sum(exp(sqrt(-1)*XDir));


                if abs(OP(i)) < 0.99 || abs(angle(OP(i))) > pi/200
                    StayTime(KK) = sum(Time(1:i));
                    break;
                end

            end
            

            if i == TotTime
                StayTime(KK) = sum(Time);
            end

        end

        

        AvgStay(AA,JJ) = mean(StayTime);
        clear StayTime;
        
    end
    
end

%plot(AvgStay)

save("Average_StayDynamics_Herd_500_500.mat","AvgStay");