function [XVel,YVel] = fun_Temporal_Position_Update(Adj,posncurr,velocitycurr,Dogposn,DogSafeDist, Dist,DogDist,AlignRate,n,AdjDistAlign,mdog, mnoise)

XVelOld = velocitycurr(1,:);
YVelOld = velocitycurr(2,:);

X = posncurr(1,:);
Y = posncurr(2,:);

%% In the alignment attraction phase, they align and attract each other. 

DistMod = Dist;
DistMod(DistMod == 0) = 1; %Since we are diving by Distance, zeros would create NaNs. And since AdjDistrepel etc already have diagonal as 0, it doesn't affect the result

%% Sheep Dog interaction
Xdogrepel = ((DogDist-DogSafeDist)/DogSafeDist).*(X - Dogposn(1))./DogDist; %-DogRepelRate*(X - Dogposn(1))./DogDist;%
Xdogrepel(DogDist>DogSafeDist) = 0;
Ydogrepel = ((DogDist-DogSafeDist)/DogSafeDist).*(Y - Dogposn(2))./DogDist; %-DogRepelRate*(Y - Dogposn(2))./DogDist; %
Ydogrepel(DogDist>DogSafeDist) = 0;
Xdogrepel_vel = Xdogrepel.*mdog;
Ydogrepel_vel = Ydogrepel.*mdog;


social_vel_x_mat = AdjDistAlign.*repmat(velocitycurr(1,:),n,1); %matrix containg all the x velocities
%social_vel_x_mat = social_vel_x_mat + diag(velocitycurr(1,:));

social_vel_y_mat = AdjDistAlign.*repmat(velocitycurr(2,:),n,1);
%social_vel_y_mat = social_vel_y_mat + diag(velocitycurr(2,:));

Xalign = sum(AlignRate*social_vel_x_mat,2);
Yalign = sum(AlignRate*social_vel_y_mat,2);

Xnoiselevel = ((-1).^randi(1000,1,n)).*rand(1,n).*mnoise;
Ynoiselevel = ((-1).^randi(1000,1,n)).*rand(1,n).*mnoise;


%end

XVel = (Xalign-Xdogrepel_vel'-Xnoiselevel')';
YVel = (Yalign-Ydogrepel_vel'-Ynoiselevel')';

Mag = sqrt((XVel.^2 + YVel.^2)); % This is magnitude of velocity
Mag(Mag==0) = 1;

XVel = XVel./Mag;%Unit vector along the direction
YVel = YVel./Mag;%Unit vector along the direction


end