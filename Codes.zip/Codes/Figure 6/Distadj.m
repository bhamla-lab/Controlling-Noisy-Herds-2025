function  [Adj, TotDist, DogDist,WallDist] = Distadj(posncurr, dogposn, MaxDist, SheepSize,halfWorld,n)

Adj = zeros(n);
dogdiff = posncurr-dogposn;
walldiff = abs(posncurr-sign(posncurr)*halfWorld);
DogDist = sqrt(dogdiff(1,:).^2 + dogdiff(2,:).^2);
WallDist = min(abs(walldiff));% if wall is the boundary %sqrt(walldiff(1,:).^2 + walldiff(2,:).^2); If wall is a person or a dog

X = posncurr(1,:);
Y = posncurr(2,:);

SheepNo = length(X);

TotDist = sqrt((repmat(X,length(X),1)-repmat(X,length(X),1)').^2 + (repmat(Y,length(Y),1)-repmat(Y,length(Y),1)').^2);

%% If three sheep are colinear, then they are not fully connected.
% This part of the code takes 3 sheep and compares their distances to
% calculate if they are colinear or not. If they are coliear, then the
% largest connection gets cut since the farthest two sheep can't see each
% other

if SheepNo >2

for i = 1: SheepNo-2
    for j = i+1:SheepNo-1
        for k = j+1:SheepNo
            LinearTestVec = [TotDist(i,j), TotDist(j,k), TotDist(i,k)];
            Large = max(LinearTestVec);
            Large = Large(1);
            IDXLarge = find(LinearTestVec == Large);
            
            if IDXLarge == 1
                LX = i;
                LY = j;
            elseif IDXLarge == 2
                LX = j;
                LY = k;
            else
                LX = i;
                LY = k;
            end

            Small = min(LinearTestVec);
            Small = Small(1);

            IDXSmall = find(LinearTestVec == Small);
           
            if IDXSmall == 1
                SX = i;
                SY = j;
            elseif IDXSmall == 2
                SX = j;
                SY = k;
            else
                SX = i;
                SY = k;
            end
            
            IDXMiddle = find(~ismember([1:3],[IDXSmall,IDXLarge])==1);
            Middle = LinearTestVec(IDXMiddle);

            if IDXMiddle == 1
                MX = i;
                MY = j;
            elseif IDXMiddle == 2
                MX = j;
                MY = k;
            else
                MX = i;
                MY = k;
            end

            if abs(Small + Middle - Large) > SheepSize
                Adj(LX,LY) = 1;
                Adj(LY,LX) = 1;

            else
                Adj(LX,LY) = 0;
                Adj(LY,LX) = 0;
            end
            Adj(SX,SY) = 1;
            Adj(SY,SX) = 1;
            Adj(MX,MY) = 1;
            Adj(MY,MX) = 1;

        end
    end
end
else
    Adj = 1-eye(n);
end

        %% This part of the code deletes connection between any two sheep which are out of range.


        Adj(TotDist>MaxDist) = 0;
end