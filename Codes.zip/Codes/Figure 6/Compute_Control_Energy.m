

%Sheep-dog model_Binary Decision

% This code allows us to change the number of nearest neighbors a sheep is
% looking at when it is alert and also to change the alert probability.
clear all; close all;clc

% videoFile = VideoWriter('Control_Energy_ICA.avi'); % You can specify the file format as well
% videoFile.FrameRate = 10; % Set frames per second
% open(videoFile); % Open the file for writing


DeltaMean = 0.01;
Target_Posn = .3;


%% CHANGE NN EQUATION__IT IS WRONG BOTH IN BINARY DECISION AND NORMAL; DONE
for KK = 0

    NN = 1;

    %Parameters
    n= 20; %No of sheep
    L=1; %Total worldlength. World extends from -L/2 to L/2.

    halfWorld = L/2;
    MaxDist = 5*L; %Maximum distance beyond which the connection between the sheep break
    T=1000;
    if KK == 0
        NDivs = 100; % Number of division of the distance from starting to final position required for "micromanagement model"
    else
        NDivs = 100;
    end
    %NDivs = 1;
    Final_Posn = [Target_Posn,0];
    All_Target_Positions = (1/NDivs:1/NDivs:1) .* repmat(Final_Posn', 1,NDivs);

    dt= .01;
    delay=0.1;
   
    %r=.5; %social radius

    %% Parameters (Generalized for AAA model, but we only consider alignment not attraction or avoidance.

    R = 2*L; % Maximum distance after which there is no interaction between two agents 
    r = 0; % Minimum distance between two agents to align. Beyond this they will repel. For this model r = 0.
    RepelRate = 0;
    AttrRate = 0;
    AlignRate = 1;
    %DogRepelRate = .1;
    NoiseRate =0.00;
    SheepSize = .001;

    %Variables and initialization
    posn = [-0.3;0]+(halfWorld/10)*(2*rand(2,n)-1);
    %InitialDist = posn - [0;0];
    %InitialVar = mean(InitialDist(1,:).^2 + InitialDist(2,:).^2);

    InitialVar = var( posn(2,:));

    DeltaVar = 2*InitialVar;
    mean(posn,2)
    Dogposn = [-L/2 ;0];%halfWorld*(2*rand(2,1)-1);
    DogSafeDist =L/2;

    theta = 2*pi*rand(1,n);
    velocity = [cos(theta); sin(theta)];

    %Debug: the magnitude must be 1 x n vector.
    %magnitute=velocity(1,:).^2 + velocity(2,:).^2

    CMass = [];
    Next_Posn = All_Target_Positions(:,1)';

    for t=1:T
        pause(delay)

        %Store current values of posn, vel and direction
        posncurr = posn;
        velocitycurr = velocity;


        [Adj, Dist, DogDist,WallDist] = Distadj(posncurr, Dogposn, MaxDist, SheepSize,halfWorld,n); %Tracks all connections and distances

        Oldvelocity = velocity;
        Oldposn = posn;

 

        for drp = 1:10000
            DogRepelRate = (drp)*.01;
            TotRate = AlignRate + NoiseRate + DogRepelRate;

            pdog = DogRepelRate/TotRate;
            pNoise = NoiseRate/TotRate;

          MRand = rand(T,n); %Generates binary sequence of on and off
            M = MRand; %Generates binary sequence of on and off
            M(M<pdog) = 100;
            M(M>=pdog & M<(pdog+pNoise)) = 200;
            M(M>=(pdog+pNoise)& M<=1) = 300;

            m = M(t,:);

            %Allignment time

            if KK == 1
                [velocity(1,:),velocity(2,:)] = UpdatePosition_binary_decision_Noise(Adj,posncurr,velocitycurr,Dogposn,DogSafeDist, Dist,DogDist,AlignRate,DogRepelRate,n,r,R,m,NN);%UpdatePosition_binary_decision(Adj,posncurr,velocitycurr,Dogposn,DogSafeDist, Dist,DogDist,WallDist,RepelRate,AttrRate,AlignRate,DogRepelRate,WallRepelRate,n,r,R,BrokR,halfWorld,m,NN, noise);
            else
                [velocity(1,:),velocity(2,:)] = UpdatePosition_Avg_Noise(Adj,posncurr,velocitycurr,Dogposn,DogSafeDist,Dist,DogDist, AlignRate,DogRepelRate, NoiseRate, n,r,R,NN);

            end

            posn = posn + velocity*dt;

            yMean = mean(posn(2,:));
            
            if abs(yMean) < DeltaMean && mean(velocity(1,:))>0 && var(posn(2,:)) <= DeltaVar
                Udog(t) = DogRepelRate;
                break;
            else
                
                posncurr = Oldposn;
                posn = Oldposn;
                velocitycurr = Oldvelocity;
                velocity = Oldvelocity;

            end
        end

        if mean(posn(1,:)) >= Target_Posn
            break;
        end
        %
        %[DogRepelVelocity(1,:),DogRepelVelocity(2,:)] = DogScare(posncurr,Dogposn,DogSafeDist,DogDist,DogRepelRate);
        %     %Add random fluctuations to that direction.



        [Dogposn,Direction(:,t)] = DogPosnUpdate(Dogposn,DogDist,DogSafeDist,DogRepelRate,posn,Next_Posn);

        idx = find(All_Target_Positions(1,:)> mean(posn(1,:)),1,'first');

        Next_Posn = All_Target_Positions(:,idx)';

        CMass = [CMass mean(posn,2)];
        % Update the new periodic position.


        XDirX = velocity(1,:);
        XDirY = velocity(2,:);
        scatter(posn(1,:),posn(2,:),20,'filled','MarkerEdgeColor',[0.8500 0.3250 0.0980],...
            'MarkerFaceColor',[0.8500 0.3250 0.0980]);
        hold on
        hq = quiver(posn(1,:),posn(2,:),0.05*XDirX,0.05*XDirY,'off','-r');
        U = hq.UData;
        V = hq.VData;
        X = hq.XData;
        Y = hq.YData;

        for ii = 1:length(X)
            %  for ij = 1:length(X)

            headWidth = 10;
            ah = annotation('arrow',...
                'headStyle','hypocycloid','HeadWidth',headWidth);
            set(ah,'parent',gca);
            set(ah,'position',[X(ii) Y(ii) U(ii) V(ii)]);

            % end
        end
        scatter(Dogposn(1),Dogposn(2),50,'filled')
        hold on

        ColorLine = linspace(0,3*pi, size(CMass,2));

        c = linspace(10,20,length(ColorLine));
        
        scatter(CMass(1,:),CMass(2,:),20,c,'filled')
        % yline([00.05 -0.05],'--','LineWidth',3)
         if KK == 1
         colormap(flipud('summer'));
         else
          colormap(flipud('spring')); 
         end
         

        xlim([-halfWorld, halfWorld]);
        ylim([-halfWorld, halfWorld]);
      
        hold off

%  % Capture the plot as a frame
%     frame = getframe(gcf);
%     
%     % Write the frame to the video file
%     writeVideo(videoFile, frame)
%          

    end

    FinalDist = posn - Final_Posn';

   
end
% close(videoFile)





