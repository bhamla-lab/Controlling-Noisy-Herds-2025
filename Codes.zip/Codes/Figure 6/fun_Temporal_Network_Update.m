function [AdjDistAlign,mdog,mnoise, M_Matrix_Random] = fun_Temporal_Network_Update(Update_Ratio,n, pdog, pNoise, Flag, AdjDistAlign,M_Matrix_Random,mdog, mnoise)

if Flag == 1

    clear M_Matrix_Random; % If flag = 1, then the old random matrix gets deleted and a new random matrix is created

    if Update_Ratio < 1 % Towards LF
        Update_Ratio = 1; % Since flag = 1, this is the cycle in which the network updates
    end

    M_Matrix_Random = rand(Update_Ratio,n); % New random matrix
    M_Matrix = M_Matrix_Random;
    M_Matrix(M_Matrix<pdog) = 100; % Controller influence
    M_Matrix(M_Matrix>=pdog & M_Matrix<(pdog+pNoise)) = 200; %Noise Inflluence
    M_Matrix(M_Matrix>=(pdog+pNoise)& M_Matrix<=1) = 300; % Agent-Agent interaction influence
    
    mdog = sum(M_Matrix == 100,1); % Total weight on the controller influence

    mnoise = sum(M_Matrix == 200,1); % Total weight on the noise influence

    %% Influence of the interaction influence: Create a n*n matrix where each agent randomly chooses another agent to interact with. For Update Ratio > 1, the number of times one interacts with another agent and controller it interacts with is equal to update ratio. 

    % Parameters
    rangeMin = 1;
    rangeMax = n+1;      % Maximum value in the range
    numElements = Update_Ratio;   % Number of random numbers per row
    numRows = n;       % Number of rows in the matrix


% Create the valid numbers matrix, excluding each row's corresponding number
validNumbersMatrix = zeros(numRows, rangeMax - 1);  
for i = 1:numRows
    validNumbersMatrix(i, :) = [rangeMin:i-1, i+1:rangeMax];  % Exclude i
end

% Generate random indices to sample n-1 numbers per row from the n-1 valid numbers
randomIndices = randi(rangeMax - 1, numRows, numElements);

% Use the random indices to create the final matrix
Intermitt_Matrix = validNumbersMatrix(sub2ind(size(validNumbersMatrix), ...
                          repmat((1:numRows)', 1, numElements), randomIndices));

    randomMatrix = Intermitt_Matrix';
    randomMatrix(M_Matrix < 300) = 0; % Delete all the controller and noise influences

    % Find non-zero elements and their positions
    [~,cols, values] = find(randomMatrix);

    % Keep only values that are valid subscripts: 1 <= value <= n
    validIdx = values >= 1 & values <= n;
    cols = cols(validIdx) ;  % Filter valid column indices
    values = values(validIdx);  % Filter valid values

    if Update_Ratio <= 1
        C = [cols', values'];
    else
        C = [cols, values];
    end

    % Create the P matrix with dimensions (n x n)

    if isempty(C) == 1
        AdjDistAlign = zeros(n);
    else
         AdjDistAlign = accumarray(C, 1, [n, n], @sum, 0);
    end

else

    mnoise_old = mnoise;
    mdog_old = mdog;

    M_Matrix = M_Matrix_Random; % This remains fixed; only pdog changes
    M_Matrix(M_Matrix<pdog) = 100;
    M_Matrix(M_Matrix>=pdog & M_Matrix<(pdog+pNoise)) = 200;
    M_Matrix(M_Matrix>=(pdog+pNoise)& M_Matrix<=1) = 300;

    mdog = sum(M_Matrix == 100,1);

    mnoise = sum(M_Matrix == 200,1);

    DiffIDX_dog = mdog-mdog_old > 0;
    DiffIDX_noise = mnoise-mnoise_old > 0;

    AdjDistAlign(DiffIDX_dog,:) = 0;
    AdjDistAlign(DiffIDX_noise,:) = 0;
end

end