function [Dogposn, Direction] = DogPosnUpdate(Dogposn,DogDist,DogSafeDist,DogRepelRate,posn,Next_Posn)
meanposn = mean(posn,2); %Center of mass of the sheep-herd


Direction = Next_Posn'-meanposn;

Dogposn = meanposn - (DogSafeDist-0.1)*Direction./norm(Direction);

end