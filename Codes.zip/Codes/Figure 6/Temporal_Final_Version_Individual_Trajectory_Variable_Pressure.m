
%% This is an updated code for temporality. Here there is just one parameter Update ratio (UR) that shows how many times network updates for every velocity update. If UR > 1,
%% every cycle, each agent finds UR other agent (obeying probabilities) including the dog and averages. It may be repeating.
%% Each drp is considered physical, Meaning that the dog waits and increases the pressure. Hence every drp, it would average and there is no memory.

%% If UR < 1, every 1/UR cycle, the network updates, the rest of the cycles, the panic factor M and the network remains the same. The drp decides who is a part of the network and who runs away.


%% Temporality: This code shows why temporality is important!
%% It is the same idea of control energy. The dog has to keep them inside the two boundaries, move forward and maintain a max variance
%% There are two time scales update time scale and network time scale. At every update time scale the dog calculates the pressure to keep them inside the boundary and move forward and keep the variance under control. That remains the pressure until the next update happens

clear all;clc

URTable = [.01]; %Temporality (Temporality -> 0 is LFSA and Temporality -> infinity is ASA. Temporality = 1 is ISA

for UR = 1

Update_Ratio = URTable(UR);

DeltaMean = 0.1;
Target_Posn = .1;
NN = 1;
MaxDRP = 10000;
%Update_Ratio = .1; %% how many times network updates for every velocity update.

n = 50;


%Parameters

L = 1; %Total worldlength. World extends from -L/2 to L/2.

halfWorld = L/2;
MaxDist = 5*L; %Maximum distance beyond which the connection between the sheep break
T=2;
NDivs = 1000;
%NDivs = 1;
Final_Posn = [Target_Posn,0];
All_Target_Positions = (1/NDivs:1/NDivs:1) .* repmat(Final_Posn', 1,NDivs);

dt= .01;
delay= 0;

%r=.5; %social radius

%% Parameters (Generalized for AAA model, but we only consider alignment not attraction or avoidance.

% R = 2*L; % Maximum distance after which there is no interaction between two agents
% r = 0; % Minimum distance between two agents to align. Beyond this they will repel. For this model r = 0.
%RepelRate = 0;
%AttrRate = 0;

AlignRate = 1;
%DogRepelRate = .1;
NoiseRate =0.00;
SheepSize = .000; %Unnecessary parameter

%Variables and initialization
posn = [-0.3;0]+(halfWorld/10)*(2*rand(2,n)-1);
%InitialDist = posn - [0;0];
%InitialVar = mean(InitialDist(1,:).^2 + InitialDist(2,:).^2);

InitialVar = var( posn(2,:));

DeltaVar = InitialVar;
Dogposn = [-L/2 ;0];%halfWorld*(2*rand(2,1)-1);
DogSafeDist =L/2;

theta = 2*pi*rand(1,n);
velocity = [cos(theta); sin(theta)];

CMass = [];
Next_Posn = All_Target_Positions(:,1)';

DogRepelRate = 0.01;
TotRate = AlignRate + NoiseRate + DogRepelRate;

pdog = DogRepelRate/TotRate;
pNoise = NoiseRate/TotRate;

M_Matrix_Random = rand(1,n); % The panic metric of agents

AdjDistAlign = zeros(n);
mdog = zeros(1,n);
mnoise = zeros(1,n);
Cycle_Counter = 0;

Udog = zeros(1,T);


for t=1:T
    pause(delay)

    %Store current values of posn, vel and direction
    posncurr = posn;
    velocitycurr = velocity;
    [Adj, Dist, DogDist,WallDist] = Distadj(posncurr, Dogposn, MaxDist, SheepSize,halfWorld,n); %Tracks all connections and distances

    for drp = 1:MaxDRP
        Cycle_Counter = Cycle_Counter + 1;
        DogRepelRate = (drp)*.01;
        TotRate = AlignRate + NoiseRate + DogRepelRate;

        pdog = DogRepelRate/TotRate;
        pNoise = NoiseRate/TotRate;

        if Update_Ratio >= 1
            Flag = 1;
        else
            if mod(Cycle_Counter-1,round(1/Update_Ratio)) == 0
                Flag = 1; %Flag = 1 indicates a restructuring of the network
            else
                Flag = 0;
            end
        end
        Oldposn = posn;
        Oldvelocity = velocity;

        [AdjDistAlign,mdog,mnoise, M_Matrix_Random] = fun_Temporal_Network_Update(Update_Ratio,n, pdog, pNoise, Flag, AdjDistAlign,M_Matrix_Random,mdog, mnoise); %Network Update

        [XVel,YVel] = fun_Temporal_Position_Update(Adj,posncurr,velocitycurr,Dogposn,DogSafeDist, Dist,DogDist,AlignRate,n,AdjDistAlign,mdog, mnoise); %Velocity Update


        velocity = [XVel;YVel];


        posn = posn + velocity*dt;

        yMean = mean(posn(2,:));
        if abs(yMean) < DeltaMean && mean(velocity(1,:))>0 && var(posn(2,:)) < DeltaVar
            Udog(t) = DogRepelRate;
            break;
        else
            posncurr = Oldposn;
            posn = Oldposn;
            velocitycurr = Oldvelocity;
            velocity = Oldvelocity;

        end
        %% If all agents are following the controller, it doesn't need to apply any more pressure
        if Update_Ratio >= 1
            if all(mdog == Update_Ratio)
                Udog(t) = DogRepelRate;
                break;
            end
        else
            if nnz(~mdog) == 0
                Udog(t) = DogRepelRate;
                break;
            end
        end
    end
    CMass = [CMass mean(posn,2)];

    if mean(posn(1,:)) >= Target_Posn
        break;
    end

    [Dogposn,Direction] = DogPosnUpdate(Dogposn,DogDist,DogSafeDist,DogRepelRate,posn,Next_Posn);

    idx = find(All_Target_Positions(1,:)> mean(posn(1,:)),1,'first');

    Next_Posn = All_Target_Positions(:,idx)';


    % Update the new periodic position.


        XDirX = velocity(1,:);
        XDirY = velocity(2,:);
        scatter(posn(1,:),posn(2,:),20,'filled','MarkerEdgeColor',[0.8500 0.3250 0.0980],...
            'MarkerFaceColor',[0.8500 0.3250 0.0980]);
        hold on
        hq = quiver(posn(1,:),posn(2,:),0.05*XDirX,0.05*XDirY,'off','-r');
        U = hq.UData;
        V = hq.VData;
        X = hq.XData;
        Y = hq.YData;


        

        for ii = 1:length(X)
            %  for ij = 1:length(X)

            headWidth = 10;
            ah = annotation('arrow',...
                'headStyle','hypocycloid','HeadWidth',headWidth);
            set(ah,'parent',gca);
            set(ah,'position',[X(ii) Y(ii) U(ii) V(ii)]);

            % end
        end
        scatter(Dogposn(1),Dogposn(2),50,'filled')
        hold on

        ColorLine = linspace(0,3*pi, size(CMass,2));

        c = linspace(10,20,length(ColorLine));
        
        scatter(CMass(1,:),CMass(2,:),20,c,'filled')
        % yline([00.05 -0.05],'--','LineWidth',3)


        if UR == 1
        
          colormap(flipud('spring')); 

        elseif UR == 2
            colormap(flipud('hot'));
        else
             colormap(flipud('summer'));
        end
         

        xlim([-3*halfWorld, 3*halfWorld]);
        ylim([-3*halfWorld, 3*halfWorld]);

        yline([DeltaMean -DeltaMean],'--','LineWidth',1)
      
        hold off

%     filename = sprintf('Trajectory_UR_%d_%d.svg', Update_Ratio, t);  % Create a unique filename
%     saveas(gcf, filename); 

end

%UdogFile = sprintf('Udog_Info_%d.mat', Update_Ratio);  % Create a unique filename
%save(UdogFile,'Udog');

SaveCMass(:,:,UR) = CMass;

end






